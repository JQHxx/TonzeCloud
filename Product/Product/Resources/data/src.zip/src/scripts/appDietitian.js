
requirejs(['zepto','app/dietitian'],function($,Dietitian) {
  $(function($){
    var dietitian = new Dietitian;
  })
});
