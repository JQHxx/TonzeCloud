
requirejs(['zepto','app/menu'],function($,Menu) {
  $(function($){
    var menu = new Menu;
  })
});
