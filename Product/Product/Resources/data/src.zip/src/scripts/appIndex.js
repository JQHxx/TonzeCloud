
requirejs(['zepto','app/index'],function($,Index) {
  $(function($){
    var index = new Index;
  })
});
