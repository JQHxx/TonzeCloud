define(function(require, exports, module) {
  var _ = require('underscore');
  /*
  * @author Qadir
  * @name {function} 模板
  * @return {object}
  */
  function tplSports(){

    //运动详情
    var tplSportsDetails = _.template('<%_.each(obj,function(item,i){%><section class="section-cover-plan"><img src="<%=item.image%>" /></section>'
      +'<section class="section-sports-info"><div class="intro-info"><h3 class="name"><%=item.name %></h3>'
      +'<div class="cf sub"><span class="date"><%=item.create_time %></span><i class="fr view"><%=item.pageviews %>浏览</i></div>'
      +'<div class="text"><%=item.synopsis %></div></div><div class="set"><div class="row"><h3 class="title">适宜人群</h3><p class="text"><%=item.min_age %>岁-<%=item.max_age %>岁人群</p>'
      +'<div class="image-text"><div class="text"><%=item.text %></div></div></div></div></section> <%})%>');

     //运动筛选弹窗
    var tplSportFilter = _.template('<div class="mui_mask"></div><div class="mui_dialog"><div class="mui_dialog_body">'
      +'<div class="mui_dialog_hd"><div class="title"><span>适用人群</span><a class="btn-cancel">取消</a></div></div>'
      +'<div class="mui_dialog_bd"><div class="dialog_bd_labels"><div class="labels cf"><%_.each(obj,function(item,i){%> <a class="label<%if(item.status){%> selected <%}%>"><%=item.name %></a> <%})%> </div></div></div>'
       +'<div class="mui_dialog_hd"><div class="title"><span>性别</span></div></div>'
      +'<div class="mui_dialog_bd"><div class="dialog_bd_labels"><div class="labels cf"><%_.each(obj,function(item,i){%> <a class="label<%if(item.status){%> selected <%}%>"><%=item.name %></a> <%})%> </div></div></div>'
       +'<div class="mui_dialog_hd"><div class="title"><span>年龄</span></div></div>'
      +'<div class="mui_dialog_bd"><div class="dialog_bd_labels"><div class="labels cf"><%_.each(obj,function(item,i){%> <a class="label<%if(item.status){%> selected <%}%>"><%=item.name %></a> <%})%> </div></div></div>'
      +'<div class="mui_dialog_ft"><a class="mui_dialog_button reset">重置</a><a class="mui_dialog_button confirm">确定</a></div></div></div>')

    return {
      tplSportsDetails:tplSportsDetails,
      tplSportFilter:tplSportFilter
    }
  }
  module.exports = tplSports();
});