define(function(require, exports, module) {
  var _ = require('underscore');
  /*
  * @author Qadir
  * @name {function} 专家模板
  * @return {object}
  */
  function tplDietitian(){

    //专家详情
    var tplDietitianDetails = _.template('<%_.each(obj,function(item,i){%> <div class="bg-info"><div class="info"><div class="pic"><img src="<%=item.image%>"></div>'
      +'<h3 class="name"><%=item.name%></h3><% var labelsStr = item.label.join(\'\/\');  %><p class="labels"><%=labelsStr %></p></div></div><div class="intro-info"><p class="text packup"><%=item.synopsis%></p>'
      +'<div class="unfold js-unfold"><a>展开全部</a></div></div> <%})%>');

    //专家筛选弹窗
    var tplDietitianFilter = _.template('<div class="mui_mask"></div><div class="mui_dialog"><div class="mui_dialog_body">'
      +'<div class="mui_dialog_hd"><div class="title"><span>按疾病</span><a class="btn-cancel">取消</a></div></div>'
      +'<div class="mui_dialog_bd"><div class="dialog_bd_labels"><div class="labels cf"><%_.each(obj,function(item,i){%> <a class="label<%if(item.status){%> selected <%}%>"><%=item.name %></a> <%})%> </div></div></div>'
      +'<div class="mui_dialog_ft"><a class="mui_dialog_button reset">重置</a><a class="mui_dialog_button confirm">确定</a></div></div></div>')

    return {
      tplDietitianDetails:tplDietitianDetails,
      tplDietitianFilter:tplDietitianFilter
    }
  }
  module.exports = tplDietitian();
});