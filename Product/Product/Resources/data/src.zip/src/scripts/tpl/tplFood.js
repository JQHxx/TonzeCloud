define(function(require, exports, module) {
  var _ = require('underscore');
  /*
  * @author Qadir
  * @name {function} 模板
  * @return {object}
  */
  function tplFood(){
    //食材详情
    var tplFoodDetails = _.template('<section class="section-cover-plan"><img src="images/pic_006.jpg" /></section>'
    +'<%_.each(obj,function(item,i){ %> <section class="section-food-info"> <div class="intro-info"><h3 class="name"><%=item.name %></h3>'
    +'<p class="text packup"><%=item.instructions %></p><div class="unfold"><a>展开全部</a></div></div>'
    +'<div class="set"><div class="row"><h3 class="title">适用人群</h3><% var tagStr = item.tags||[].join("、");%> <p class="text"><%=tagStr %></p></div>'
    +'<div class="row"><h3 class="title">适用性别</h3><p class="text"><%=item.appropriate_gender%></p></div>'
    +'<div class="row"><h3 class="title">适用年龄</h3><p class="text"><%=item.min_age%>岁-<%=item.max_age%>岁</p></div></div></section></div> <%})%>');

    return {
      tplFoodDetails:tplFoodDetails
    }
  }
  module.exports = tplFood();
});