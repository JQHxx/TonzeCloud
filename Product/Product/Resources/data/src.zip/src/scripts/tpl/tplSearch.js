define(function(require, exports, module) {
  var _ = require('underscore');
  /*
  * @author Qadir
  * @name {function} 模板
  * @return {object}
  */
  function tplSearch(){

    //历史搜索列表
    var tplHistoryList = _.template('<%_.each(obj,function(item,i){%> <a data-href="<%=item.link %>"><%=item.name %></a> <%})%>')

    //搜索提示列表
    var tplTipsList =  _.template('<%_.each(obj,function(item,i){%> <li><a data-href="<%=item.link %>" <% if(item._id){ %> data-id="<%=item._id %>"<%}%> ><%=item.name %></a></li> <%})%>');

    return {
      tplHistoryList:tplHistoryList,
      tplTipsList:tplTipsList
    }
  }
  module.exports = tplSearch();
});