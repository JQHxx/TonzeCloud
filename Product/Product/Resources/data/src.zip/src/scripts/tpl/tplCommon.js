define(function(require, exports, module) {
  var _ = require('underscore');
  /*
  * @author Qadir
  * @name {function} 通用模板
  * @return {object}
  */
  function tplCommon(){

    //专家列表
    var tplDietitianList = _.template('<%_.each(obj,function(item,i){ var name = encodeURIComponent(item.name); %><a href="dietitianDetails.html?_id=<%=item._id%>&name=<%=name%>" class="cf dietitian">'
      +'<div class="pic fl"><img src="<%=item.image%>" /></div>'
      +'<div class="info"><h3><%=item.name%></h3><p class="intro"><%=item.synopsis%></p>'
      +'<div class="labels"><%_.each(item.label,function(item,i){ %><span class="label"><%=item%></span> <%})%></div></div><i class="icon-arrow"></i></a> <%})%>');

    //专家头像列表
    var tplDietitianPicList = _.template('<%_.each(obj,function(item,i){%> <div class="swiper-slide"><a href="dietitianDetails.html?_id=<%=item._id %>"><img src="<%=item.image %>" /></a></div> <%})%>');

    //菜谱列表
    var tplMenuList = _.template('<%_.each(obj,function(item,i){%>'
      +'<a href="menuDetails.html?_id=<%=item._id %>" class="cf item">'
      +'<div class="pic fl"><img src="<%=item.images[0] %>" /><% if( item.properties.symptom){ var symptom = item.properties.symptom %><b class="cover"><%=symptom[0].name %></b> <%}%></div>'
      +'<div class="info"><div class="name"><span><%=item.name %></span><i class="icon-cloud"></i></div>'
      +'<p class="intro"><%=item.instructions %></p>'
      +'<div class="labels"><% _.each(item.tags,function(item,i){ if (item){ %><span class="label"><%=item %> </span> <% }})%> </div></div> </a> <%})%>');

  //食材列表
    var tplFoodList = _.template('<%_.each(obj,function(item,i){var images = item.images||[] %> <a href="foodDetails.html?_id=<%=item._id %>" class="cf item">'
      +'<div class="pic fr"><img src="<%=images[0] %>"></div>'
      +'<div class="info"><div class="name"><span><%=item.name %></span></div>'
      +'<p class="intro"><%=item.instructions %></p>'
      +'<div class="labels"><% _.each(item.tags,function(item,i){ if (item){ %> <span class="label"><%=item%> </span> <%}})%> </div></div> </a> <%})%>');

    //运动列表
    var tplSportsList = _.template('<%_.each(obj,function(item,i){ var images = item.images||[] %> <a href="sportsDetails.html?_id=<%=item._id %>" class="cf item">'
      +'<div class="pic fl"><img src="<%=item.image %>"></div>'
      +'<div class="info"><div class="name"><span><%=item.name %></span><i class="view"><% if( item.pageviews ){ %><%=item.pageviews%>人浏览<%}%></i></div>'
      +'<p class="intro"><%=item.synopsis %></p>'
      +'<div class="labels"> <%_.each(item.label,function(item,i){%><span class="label"><%=item%></span> <%})%> </div></div></a> <%})%>');

    //报告列表
    var tplReportList = _.template('<%_.each(obj,function(item,i){%> <a href="reportDetails.html?_id=<%=item._id %>" class="item">'
      +'<div class="info cf"><span class="name fl"><%=item.RecordNo %></span></div>'
      +'<p class="explain">来自：<%=item.DeviceType %>（<%=item.MachineId %>）</p><p class="time"><%=item.create_time %></p><i class="icon-arrow"></i></a> <%})%>');

    return {
      tplDietitianList:tplDietitianList,
      tplDietitianPicList:tplDietitianPicList,
      tplMenuList:tplMenuList,
      tplFoodList:tplFoodList,
      tplSportsList:tplSportsList,
      tplReportList:tplReportList
    }
  }
  module.exports = tplCommon();
});