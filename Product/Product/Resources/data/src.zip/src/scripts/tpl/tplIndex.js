define(function(require, exports, module) {
  var _ = require('underscore');
  /*
  * @author Qadir
  * @name {function} 首页模板
  * @return {object}
  */
  function tplIndex(){

    //用户标签弹窗
    var tplDialog = _.template('<div class="mui_dialog_userlabels"><div class="mui_mask"></div>'
        +' <div class="mui_dialog"><div class="mui_dialog_body"><div class="mui_dialog_hd">'
        +'<div class="title"><em>您好！</em>欢迎使用天际云健康app，为了更好提供贴心的服务，请选择以下您所关注的健康标签：</div></div>'
        +'<div class="mui_dialog_bd"><div class="dialog_bd_labels cf">'
        +'<% _.each(obj.list,function(item,i){ %><a data-id=<%=item._id %> class="label"><%=item.label %></a>'
        +'<%})%></div></div>'
        +'<div class="mui_dialog_ft"><a class="mui_dialog_button disabled" id="js-choice-confirm">确定</a></div></div></div></div>');

    //轮播图列表
    var tplSwiperList = _.template('<%_.each(obj,function(item,i){%> <%_.each(item.images,function(item,i){%> <div class="swiper-slide"><a><img src="<%=item %>" ></a> </div> <%})%> <%})%>');


    return {
      tplDialog:tplDialog,
      tplSwiperList:tplSwiperList
    }
  }
  module.exports = tplIndex();
});