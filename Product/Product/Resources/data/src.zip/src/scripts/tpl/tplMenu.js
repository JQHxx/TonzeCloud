define(function(require, exports, module) {
  var _ = require('underscore');
  /*
  * @author Qadir
  * @name {function} 首页模板
  * @return {object}
  */
  function tplMenu(){
    //菜谱详情
    var tplMenuDetails = _.template('<%_.each(obj,function(item,i){%> <section class="section-swiper-container">'
      +'<div class="swiper-container" id="js-menu-swiper-container"><div class="swiper-wrapper">'
      +'<%_.each(item.images,function(item,i){ %> <div class="swiper-slide"><a href="#"><img src="<%=item %>" ></a></div> <%})%></div>'
      +'<div class="swiper-pagination"></div></div></section>'
      +'<section class="section-menu-info" ><div class="intro-info"><h3 class="name"><%=item.name %></h3>'
      +'<p class="text packup"><%=item.instructions %></p><div class="unfold"><a>展开全部</a></div></div>'
      +'<div class="set"> <div class="row"><h3 class="title">适用设备</h3>'
      +'<ul class="device-list"><%_.each(item.devices,function(item,i){ %> <li><div class="fl pic">'
      +'<img src="<%=item.images %>"/></div><div class="explain"> <h3 class="name"><%=item.name %></h3><p>烹饪时长：<%=item.time %></p></div></li> <%})%></ul></div>'
      +'<div class="row"><h3 class="title">适用性别</h3><p class="text"><%=item.appropriate_gender %></p></div>'
      +'<div class="row"><h3 class="title">适用年龄</h3><p class="text"><%=item.min_age %>岁-<%=item.max_age %>岁</p></div>'
      +'<div class="row"><h3 class="title">食材</h3><ul class="foodMaterial-list">'
      +'<%_.each(item.major_ingredients,function(item,i){ %> <li class="cf"><span class="fl"><%=item.name %></span><b class="fr"><%=item.unit %></b></li> <%})%>'
      +'<%_.each(item.minor_ingredients,function(item,i){ %> <li class="cf"><span class="fl"><%=item.name %></span><b class="fr"><%=item.unit %></b></li> <%})%></ul></div>'
      +'<div class="row"><h3 class="title">步骤</h3><ul class="step-list">'
      +'<%_.each(item.cooking_steps,function(item,i){ %> <li><div class="cf explain"><span class="fl num"><%=item.index %></span><p><%=item.description %></p></div>'
      +'<div class="pic"><img src="<%=item.images %>"></div></li> <%})%></ul></div>'
      +'<div class="row"><h3 class="title">小贴士</h3><ul class="tips-list"><li><%=item.tips %></li></ul></div>'
      +'</div></section></div> <%})%>');

    //厨具列表
    var tplCookingList = _.template('<%_.each(obj,function(item,i){%><li data-type="<%=item.type %>" data-mac="<%=item.mac %>" data-id="<%=item.deviceType %>" class="cf">'
      +'<b class="pic" style="background-image:url(images/device/<%=item.deviceType %>.png)"></b>'
      +'<span class="name"><%=item.name %></span><i class="icon"></i><em class="status fr">空闲</em>'
      +'</li><%})%>');

    return {
      tplMenuDetails:tplMenuDetails,
      tplCookingList:tplCookingList
    }
  }
  module.exports = tplMenu();
});