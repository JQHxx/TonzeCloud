
requirejs(['zepto','app/food'],function($,Food) {
  $(function($){
    var food = new Food;
  })
});
