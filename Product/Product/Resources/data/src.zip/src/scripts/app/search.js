define(function(require, exports, module) {
  var Class = require('helper/Class');
  var tplSearch = require('tpl/tplSearch');

  var FastClick = require('fastclick');
  var util = require('helper/util');
  var Common = require('app/common');
  var common = new Common;
  var Hybrid = require('helper/Hybrid');

  /*
  * @author Qadir
  * @name {class} 搜索
  */
  var Search = Class.create();

  Search.prototype = {
    constructor: Search,
    /*
    * @public {function} 初始化
    */
    initialize:function(type){
      var self = this
      console.info('搜索类型：%s',type)
      self.type = type||'dietitian';
      self.getCacheHistory();
      self.loadSearchResult();
      self.bindEvents();
    },
    /*
    * @public {function} 获取缓存的历史搜索记录
    */
    getCacheHistory:function(){
      var $sectionSearchHistory = $('#js-section-search-history')
      if( typeof $sectionSearchHistory.get(0) ==='undefined' ) return;
      var self = this;
      var history_cache = util.getItem(common.history_cache)||{}
      var list = !util.isEmptyObject(history_cache) ?
        history_cache[common.history_cache + '_'+ self.type] ? history_cache[common.history_cache+'_'+ self.type] : []
        : []

      var len = list.length
      var $historyList = $sectionSearchHistory.find('.history-list')
      var html = ''

      if( len ){
        $sectionSearchHistory.show();
        html = tplSearch.tplHistoryList(list);
        $historyList.empty().html(html);
      }
    },
    /*
    * @public {function} 缓存历史搜索记录
    */
    setCacheHistory:function(data){
      var self = this;
      if( !data ) return;
      var history_cache = util.getItem(common.history_cache)||{}
      var list = !util.isEmptyObject(history_cache) ?
        history_cache[common.history_cache + '_'+ self.type] ? history_cache[common.history_cache+'_'+ self.type] : []
        : []
      $.each( list,function(index,obj){
        if( obj.name == data.name ){
          //删除指定的项
          list.splice(index,1);
        }
      })
      var len = list.length;

      if( len == 8 ){
        //移除最后一个元素
        list.pop();
      }
      //前端插入新元素
      list.unshift(data);

      history_cache[common.history_cache + '_'+ self.type] = list;
      util.setItem(common.history_cache,history_cache,24*30*12);
    },
    /*
    * @public {function} 下拉提示
    */
    suggest:function(keyword){
      var self = this
      var $sectionSearchResult = $('#js-section-search-result'),
      $sectionSearchHistory = $('#js-section-search-history'),
      hlen = $sectionSearchHistory.find('.history-list').children().size()
      if( !keyword ){
         $sectionSearchResult.hide();
        if( hlen )
          $sectionSearchHistory.show();
        return;
      }
      var condition = {
        limit: 20000,
        query: {},
        order: {
          created_at: -1
        }
      }
      switch(self.type){
        case 'dietitian'://专家
          condition.query['name'] = {$regex:keyword,$options:"i"}
          //condition.query['label'] = {$regex:keyword,$options:"i"}
          common.ajaxAppLoginToken().then(function(lData){
             //专家应用申请凭证
            common.ajaxApplyToken(common.dietitian_appid,lData)
            .then(function(aData){
              var url = common.apiHost+'/module/experts/'+aData.app_id+'/api/experts/list'
              //获取列表
              self.getDataSearchList(url,aData,condition);
            });
          })
        break;
        case 'sports'://运动
          condition.query['name'] = {$regex:keyword,$options:"i"}
          common.ajaxAppLoginToken().then(function(lData){
             //内容管理应用申请凭证
            common.ajaxApplyToken(common.content_appid,lData)
            .then(function(aData){
               var url = common.apiHost+'/module/contents/'+aData.app_id+'/api/article/list';
                //获取列表
                self.getDataSearchList(url,aData,condition);
            });
          })
        break;
        case 'food'://食材
          condition.query['name'] = {$regex:keyword,$options:"i"}
          common.ajaxAppLoginToken().then(function(lData){
             //菜谱应用申请凭证
            common.ajaxApplyToken(common.menu_appid,lData)
            .then(function(aData){
              var url = common.apiHost+'/module/recipes/'+aData.app_id+'/api/ingredient/list';
                //获取列表
              self.getDataSearchList(url,aData,condition);
            });
          })
        break;
      }

    },
    /*
    * @public {function} 获取搜索列表数据
    * @param {object} aData 申请应用数据
    * @param {object} qData 查询对象
    * @param {number} no 页码，默认是0
    * @param { number } flag 0:刷新，1:加载更多
    */
    getDataSearchList:function(url,aData,qData,no,flag){
      var self = this,
      data = qData;
      data.offset = parseInt(no||0) * data.limit;
      flag = flag || 0;

      var jsonData = JSON.stringify(data);
      util.appAjax({
        url:url,
        data:jsonData,
        headers:{'Access-Token':aData.access_token}
      }).done(function(data){
        console.info("获取搜索列表响应的数据:%o",data);
        self.fillDataSearchList(data.list,flag);
      }).fail(function(xhr, errorType, error){
        console.error(errorType + ':' + error);
      });
    },
    /*
    * @public {function} 绑定搜索列表数据
    * @param {array} objArr 对象的数组
    */
    fillDataSearchList :function( objArr,flag ){
      var self = this
      var $keyword = $('#keyword'),
      keyword = $keyword.val(),
      $sectionSearchResult = $('#js-section-search-result'),
      $sectionSearchHistory = $('#js-section-search-history'),
      $list = $sectionSearchResult.find('.result-list'),
      rlen = objArr.length,
      hlen = $sectionSearchHistory.find('.history-list').children().size(),
      link = ''
      $.each(objArr,function(index,obj){
        switch(self.type){
          case 'dietitian':
            link = 'dietitianDetails.html';
          break;
          case 'sports':
           link = 'sportsDetails.html';
          break;
          case 'food':
           link = 'foodDetails.html';
          break;
        }
        obj.link = link;
      })
      if( rlen ){
        $sectionSearchHistory.hide();
      }else{
        switch(self.type){
          case 'dietitian':
            link = 'dietitianSearchResult.html';
          break;
          case 'sports':
           link = 'sportsSearchResult.html';
          break;
          case 'food':
           link = 'foodSearchResult.html';
          break;
        }
        objArr = [{'name':'查找"'+ keyword +'"','link':link }];
      }
      $sectionSearchResult.show();
      var html = tplSearch.tplTipsList(objArr);

      if( flag == 0 ){
        $list.empty();
      }
      $list.append(html);
    },

    /*
    * @public {function} 装载搜索结果数据
    */
    loadSearchResult:function(){
      var self = this;
      if( typeof $('#js-search-result-wrap').get(0) ==='undefined' ) return;
      var keyword = decodeURIComponent(util.queryString('keyword')||'');
      $('#keyword').val(keyword);
      var condition = {
        query: {}
      }
      switch(self.type){
        case 'dietitian':
          condition.query['name'] = {$regex:keyword,$options:"i"}
          common.ajaxAppLoginToken().then(function(lData){
             //专家应用申请凭证
            common.ajaxApplyToken(common.dietitian_appid,lData)
            .then(function(aData){
                //获取列表
                common.getDataList(aData,condition);
            });
          })
        break;
        case 'sports':
          condition.query['name'] = {$regex:keyword,$options:"i"}
          common.ajaxAppLoginToken().then(function(lData){
             //内容管理应用申请凭证
            common.ajaxApplyToken(common.content_appid,lData)
            .then(function(aData){
                //获取列表
                common.getDataList(aData,condition);
            });
          })
        break;
        case 'food':
          condition.query['name'] = {$regex:keyword,$options:"i"}
          common.ajaxAppLoginToken().then(function(lData){
             //菜谱应用申请凭证
            common.ajaxApplyToken(common.menu_appid,lData)
            .then(function(aData){
                //获取列表
                common.getDataList(aData,condition);
            });
          })
        break;
      }
    },
     /*
    }
    * @public {function} 按钮搜索
    */
    search:function(){
      var keyword = $('#keyword').val();
      var self = this;
      var topage = '';
      if( !keyword ) return;

      //缓存8条搜索历史记录
      switch(self.type){
        case 'dietitian'://专家
          topage = 'dietitianSearchResult.html'
        break;
        case 'food'://食材
          topage = 'foodSearchResult.html'
        break;
         case 'sports'://运动
          topage = 'sportsSearchResult.html'
        break;
      }
      self.setCacheHistory({'link':topage,'name':keyword})
      requestHybrid({
          tagname:'forward',
          param:{
            //跳转方式，H5新开Webview跳转，最后装载H5页面
            type:'webview',
            //要去到的页面
            topage:topage,
            keyword:encodeURIComponent(keyword)
          },
          callback:function(res){
            //common.log(res);
          }
        })
    },

    /*
    * @name {function} 事件绑定
    */
    bindEvents:function(){
      var self = this
      var event = 'input'
      if(navigator.userAgent.match(/android/i) == "android"){
          event = "keyup";
      }
      FastClick.attach(document.body);
      $(document).on(event,'#keyword',function(){//下拉提示
        var keyword = $(this).val();
        self.suggest(keyword);
      }).on('tap','#js-section-search-result .result-list a',function(){//下拉提示列表跳转
        var topage = $(this).attr('data-href'),
        _id = $(this).attr('data-id')||"",
        param = {
            //跳转方式，H5新开Webview跳转，最后装载H5页面
            type:'webview',
             //要去到的页面
            topage:topage
        }
        if(_id){
          param._id = _id;
        }else{
          param.keyword = encodeURIComponent($('#keyword').val());
        }
        requestHybrid({
          tagname:'forward',
          param:param,
          callback:function(res){
            //debug&&debug.log(res);
          }
        });

      }).on('tap','#js-btn-search',function(){//搜索按钮
        self.search();
      }).on('tap','#js-section-search-history .history-list a',function(){//历史搜索跳转
        var topage = $(this).attr('data-rel');
        var keyword = $(this).text();
        requestHybrid({
          tagname:'forward',
          param:{
            //跳转方式，H5新开Webview跳转，最后装载H5页面
            type:'webview',
            //要去到的页面
            topage:topage,
            keyword:encodeURIComponent(keyword)
          },
          callback:function(res){
            //common.log(res);
          }
        });
      }).on('tap','.js-btn-back',function(){//搜索返回
        var topage = $(this).attr('data-topage') ? topage+'.html':''
         requestHybrid({
          tagname:'back',
          param:{
            //跳转方式，H5新开Webview跳转，最后装载H5页面
            type:'webview',
            //要去到的页面
            topage:topage
          },
          callback:function(res){
            //common.log(res);
          }
        });
      })

    }
  }
  module.exports = Search;
});