define(function(require, exports, module) {
  var Class = require('helper/Class');
  var tplDietitian = require('tpl/tplDietitian');
  var tplCommon = require('tpl/tplCommon');
  var FastClick = require('fastclick');
  var util = require('helper/util');
  var Common = require('app/common');
  var common = new Common;
  var Hybrid = require('helper/Hybrid');

  /*
  * @author Qadir
  * @public {class} 营养专家
  */
  var Dietitian = Class.create();

  Dietitian.prototype = {

    constructor: Dietitian,
    /*
    * @name {function} 初始化
    */
    initialize:function(){
      var self = this
      self.type = 'dietitian';
      self.keyArr = ['symptom'];
      self.filter_obj = {};
      self._account = '';
      common.ajaxAppLoginToken().then(function(lData){
        common.ajaxUserProperty(lData).then(function(pData){
          self.getDataUserProperty(lData,pData);
        });
      })
      $('#js-search #keyword').focus();
      self.bindEvents();
    },
    /*
    * @name {function} 获取用户属性
    * @param {object} lData 登陆用户数据
    * @param {object} pData 用户属性数据
    */
    getDataUserProperty:function(lData,pData){
      var self = this;
      if(pData.label){//有标签
           //专家应用申请凭证
          common.ajaxApplyToken(common.dietitian_appid,lData)
          .then(function(aData){
            //获取专家列表
            if( typeof $('#js-dietitian-list').get(0) !== 'undefined' ){
              var condition = {
                  query : {'label':{"$in":pData.label}}
              };
              common.getDataList(aData,condition,0,0,function(objArr,flag){
                self.fillDataDietitianList(objArr,flag)
              });
            }
            //获取专家详情
            if( typeof $('#js-dietitian-info').get(0) !== 'undefined' ){
              var _id = util.queryString('_id')
              self.getDataDietitianDetails(aData,{'_id':_id});
            }
          });
          //菜谱应用申请凭证
          common.ajaxApplyToken(common.menu_appid,lData)
          .then(function(aData){
            //获取菜谱列表
            if( typeof $('#js-menu-list').get(0) !== 'undefined' ){
              setTimeout(function(){
                console.log(self._account)
                var condition = {
                  query : {'creator':{"$in":self._account}}
                };
                common.getDataList(aData,condition);
              },100)
            }
          });
      }
    },
    /*
    * @public {function} 绑定专家列表数据
    * @param {array} objArr 对象的数组
    */
    fillDataDietitianList :function( objArr,flag ){
      var self = this
      var html = tplCommon.tplDietitianList(objArr);
      var $list = $('#js-dietitian-list');
      if( flag == 0 ){
        $list.empty();
      }
      $list.append(html);

      var $muiDialogFilter = $('#js-mui-dialog-filter')
      if( typeof $muiDialogFilter.get(0) === 'undefined'  ) return;

      var arr = [],oArr = [],key_obj = {}
      $.each(objArr,function(i,obj){
        $.each(obj.label,function(j,item){
          arr.push(item);
        })
      })
      //去重
      arr = util.unique(arr);
      $.each(arr,function(k,item){
        var obj = {}
        obj.name = item;
        obj.status = !1;
        oArr.push( obj );
      })
      $.each(self.keyArr,function(i,item){
        key_obj[item] = oArr;
      })
      self.setCacheFilter(key_obj);
    },

      /*
    * @public {function} 绑定筛选弹窗数据
    */
    fillDataDialogFilter:function(){
      var self = this
      var filter_cache = util.getItem(common.filter_cache)||{}
      var $muiDialogFilter = $('#js-mui-dialog-filter')
      var dialogHtml = '';
      var list = []
      $.each(self.keyArr,function(i,item){
        list  = filter_cache[ common.filter_cache +'_' + self.type ][item];
      })
      dialogHtml = tplDietitian.tplDietitianFilter(list);
      $muiDialogFilter.html(dialogHtml);
    },
    /*
    * @public {function} 获取专家详情数据
    * @param {object} aData 申请应用数据
    * @param {object} qData 查询数据
    */
    getDataDietitianDetails:function(aData,qData){
      var self = this,
      url = common.apiHost+'/module/experts/'+aData.app_id+'/api/experts/list',
      data = {
        query : {'_id':{'$in':[qData._id]}},
        limit:10
      };
      var jsonData = JSON.stringify(data);
      util.appAjax({
        url:url,
        data:jsonData,
        headers:{'Access-Token':aData.access_token}
      }).done(function(data){
        console.info("获取专家详情响应的数据:%o",data);
        // var data = {
        //      list : [
        //       {

        //           "_id" : "1",
        //           "user_id" : "123456",
        //           "image" : "images/pic_001.png",
        //           "name" : "吴医生",
        //           "label" : ["敬业1","敬业2"],
        //           "synopsis" : "111111111111111111111111111111111111111111122222222222222222222222222222222222222222222222222222222222",
        //           "isPush" : 1,
        //           "creator" :"123",
        //           "create_time" : "2016-06-15T01:03:27.453Z"
        //       }
        //     ],
        //   count : 100
        // }
        self.fillDataDietitianDetails(data.list);
        if( data.list.length )
          self._account = data.list[0].account;
      });
    },
    /*
    * @public {function} 绑定专家详情数据
    * @param {array} objArr 对象的数组
    */
    fillDataDietitianDetails :function( objArr ){
      var html = tplDietitian.tplDietitianDetails(objArr);
      var $info = $('#js-dietitian-info');
      $info.empty().append(html);
    },

     /*
    * @public {function} 获取食材列表数据
    * @param {object} aData 申请应用数据
    * @param {number} no 页码，默认是0
    * @param { number } flag 0:刷新，1:加载更多
    */
    getDataFoodList:function(aData,no,flag){
      var self = this,
      url = common.apiHost+'/module/recipes/'+aData.app_id+'/api/ingredient/list',
      data = {
        //query : {'label':{"$in":pdata.label}},
        limit:10
      };
      data.offset = parseInt(no||0) * data.limit;
      flag = flag || 0;
      var jsonData = JSON.stringify(data);
      util.appAjax({
        url:url,
        data:jsonData,
        headers:{'Access-Token':aData.access_token}
      }).done(function(data){
        console.info("获取食材列表数据响应的数据:%o",data);
        // var data =   {
        //    list : [
        //         {
        //        "_id" :"9",
        //        "name":"冬瓜",
        //        "images":["images/pic_002.jpg"],
        //        "instructions":"食材介绍食材介绍", 
        //        "properties":{"cooking_time":"mins"},
        //        "classification":[{"main":"","sub":""}],
        //        "created_time":"2016-05-17T01:03:27.453Z",
        //        "creator":"",
        //        "appropriate_gender" : "男",
        //        "max_age" : 10,
        //        "min_age" : 11,
        //        "create_id" :"123",
        //        "tags":["清热去火","高血压"]
        //         }
        //    ],
        //   count : 100

        // }
        self.fillDataFoodList(data.list,flag);
      });
    },
    /*
    * @public {function} 绑定食材列表数据
    * @param {array} objArr 对象的数组
    * @param { number } flag 0:刷新，1:加载更多
    */
    fillDataFoodList :function( objArr,flag ){
      var html = tplCommon.tplFoodList(objArr);
      var $list = $('#js-food-list');
      if( flag == 0 ){
        $list.empty();
      }
      $list.append(html);
    },
    /*
    * @public {function} 缓存筛选标签
    */
    setCacheFilter:function(data){
      var self = this
      var filter_cache = util.getItem(common.filter_cache)||{}
      filter_cache[common.filter_cache + '_'+ self.type] = data;
      util.setItem(common.filter_cache,filter_cache,24*30*12);
    },
    /*
    * @public {function} 事件绑定
    */
    bindEvents:function(){
      var self = this;
      FastClick.attach(document.body);
      $(document).on('click','.js-unfold a',function(){//展开全部
        $(this).parent().prev().removeClass('packup');
        $(this).parent().hide();
      }).on('click','#js-recommend .tab li',function(){//推荐内容tab
        if($(this).hasClass('active')) return;
        $(this).parent().children().removeClass('active');
        $(this).addClass('active');
        var rel = $(this).attr('data-rel');

        $('#js-recommend .con').children().hide();
        switch(rel){
          case 'menu':
            $('#js-menu-list').show().attr('data-no',0);
            common.ajaxAppLoginToken().then(function(lData){
              //菜谱应用申请凭证
              common.ajaxApplyToken(common.menu_appid,lData)
              .then(function(aData){
                //获取菜谱列表
                setTimeout(function(){
                  var condition = {
                    query : {'creator':{"$in":self._account}}
                  };
                  common.getDataList(aData,condition);
                },100)
              });
            });
          break;
          case 'food':
            $('#js-food-list').show().attr('data-no',0);
            common.ajaxAppLoginToken().then(function(lData){
              //食材应用申请凭证
              common.ajaxApplyToken(common.menu_appid,lData)
              .then(function(aData){
                //获取食材列表
                self.getDataFoodList(aData);
              });
            });
          break;
          case 'sports':
            $('#js-sports-list').show().attr('data-no',0);
            common.ajaxAppLoginToken().then(function(lData){
              //运动应用申请凭证
              common.ajaxApplyToken(common.content_appid,lData)
              .then(function(aData){
                //获取运动列表
                setTimeout(function(){
                  var condition = {
                    query : {'creator':{"$in":self._account}}
                  };
                  common.getDataList(aData,condition);
                },100)
              });
            });
          break;
        }
      }).on('click','.js-btn-back-h5',function(){//回退
        common.back();
      }).on('tap','#js-btn-filter',function(){//筛选
        var $muiDialogFilter = $('#js-mui-dialog-filter')
        $muiDialogFilter.show();
        self.fillDataDialogFilter();

      }).on('click','#js-mui-dialog-filter .btn-cancel,#js-mui-dialog-filter .mui_mask',function(){//取消
        var $muiDialogFilter = $('#js-mui-dialog-filter')
        var $labels = $muiDialogFilter.find('.labels')
        $labels.find('.label').removeClass('selected');
        $muiDialogFilter.hide();
      }).on('click','#js-mui-dialog-filter .reset',function(){//重置
        var $muiDialogFilter = $('#js-mui-dialog-filter')
        var $labels = $muiDialogFilter.find('.labels')
        $labels.find('.label').removeClass('selected');
      }).on('click','#js-mui-dialog-filter .labels .label',function(){//选择筛选条件
        if($(this).hasClass('selected')){
          $(this).removeClass('selected');
        }else{
          $(this).addClass('selected');
        }
      }).on('click','#js-mui-dialog-filter .confirm',function(){//筛选确定

        var $muiDialogFilter = $('#js-mui-dialog-filter')
        var filter_type = {}
        var labelArr = []
        $('#js-mui-dialog-filter .dialog_bd_labels').each(function(i){
          var key = self.keyArr[i],arr = []
          $(this).find('.label').each(function(){
            var obj = {}
            var name = $(this).text()
            var status = $(this).hasClass('selected') ? !0:!1
            obj.name = name;
            obj.status = status;
            arr.push(obj);
            if( status ){
              labelArr.push(name);
            }
          })
          filter_type[key] = arr;
        })
        $muiDialogFilter.hide();
        self.setCacheFilter(filter_type);
        common.ajaxAppLoginToken().then(function(lData){
           //专家应用申请凭证
          common.ajaxApplyToken(common.dietitian_appid,lData)
          .then(function(aData){
            //获取专家列表
            var condition = {
              query : {'label':{"$in":pData.label}}
            };
            common.getDataList(aData,condition,0,0,function(objArr,flag){
              self.fillDataDietitianList(objArr,flag)
            });
          });
        })

      }).on('tap','#keyword',function(){//搜索框获得焦点
        requestHybrid({
          tagname:'forward',
          param:{
            //跳转方式，H5新开Webview跳转，最后装载H5页面
            type:'webview',
            //要去到的页面
            topage:'dietitianSearch.html'
          },
          callback:function(res){
            //debug && debug.log(res);
          }
        });
      })
    }


  }
  module.exports = Dietitian;
});