define(function(require, exports, module) {
  var Class = require('helper/Class');
  var tplCommon = require('tpl/tplCommon');
  var tplFood = require('tpl/tplFood');
  var FastClick = require('fastclick');
  var util = require('helper/util');
  var Common = require('app/common');
  var common = new Common;
    require('plugins/swiper.jquery');
  /*
  * @author Qadir
  * @name {class} 营养食材
  */
  var Food = Class.create();

  Food.prototype = {
    constructor: Food,
    /*
    * @name {function} 初始化
    */
    initialize:function(){
      var self = this
      self.initSwiperDietitian();
      common.ajaxAppLoginToken().then(function(lData){
        common.ajaxUserProperty(lData).then(function(pData){
          self.getDataUserProperty(lData,pData);
        });
      })
       $('#js-search #keyword').focus();
      self.bindEvents();
    },
     /*
    * @name {function} 切换营养专家初始化
    */
    initSwiperDietitian:function(){
      var $swiperContainer = $('#js-dietitian-swiper-container');
      if( typeof $swiperContainer.get(0) == 'undefined') return;
      $swiperContainer.swiper({
        slidesPerView: 4.5,
        spaceBetween: 15
      })
    },
     /*
    * @name {function} 获取用户属性
    * @param {object} lData 登陆用户数据
    * @param {object} pData 用户属性数据
    */
    getDataUserProperty:function(lData,pData){
      var self = this;
      if(pData.label){//有标签
           //专家应用申请凭证
          common.ajaxApplyToken(common.dietitian_appid,lData)
          .then(function(aData){
            if( typeof $('#js-dietitian-list').get(0) !== 'undefined' ){
             var condition = {
                query : {'label':{"$in":pData.label}},
                limit:1
              };
              //获取专家列表
              common.getDataList(aData,condition);
            }
            if( typeof $('#js-dietitian-pic-list').get(0) !== 'undefined' ){
              self.getDataDietitianPicList(aData,pData);
            }
          });
          //菜谱应用申请凭证
          common.ajaxApplyToken(common.menu_appid,lData)
          .then(function(aData){
            //获取食材列表
            if( typeof $('#js-food-list').get(0) !== 'undefined' ){
              var condition = {
                limit:10
              };
              self.getDataFoodList(aData,condition);
            }
            //获取菜谱列表
            if( typeof $('#js-menu-list').get(0) !== 'undefined' ){
              common.getDataList(aData);
            }
            if( typeof $('#js-food-info').get(0) !== 'undefined' ){
              self.getDataFoodDetails(aData,{'_id':util.queryString('_id')})
            }

          });
      }
    },
    /*
    * @name {function} 获取食材列表数据
    * @param {object} aData 申请应用数据
    * @param {number} no 页码，默认是0
    * @param { number } flag 0:刷新，1:加载更多
    */
    getDataFoodList:function(aData,qData,no,flag){
      var self = this,
      url = common.apiHost+'/module/recipes/'+aData.app_id+'/api/ingredient/list',
      data = qData;
      data.offset = parseInt(no||0) * data.limit;
      flag = flag || 0;
      var jsonData = JSON.stringify(data);

      util.appAjax({
        url:url,
        data:jsonData,
        headers:{'Access-Token':aData.access_token}
      }).done(function(data){
        console.info("获取食材列表响应的数据:%o",data);
        // var data =   {
        //    list : [
        //         {
        //        "_id" :"9",
        //        "name":"冬瓜",
        //        "images":["images/pic_002.jpg"],
        //        "instructions":"食材介绍食材介绍", 
        //        "properties":{"cooking_time":"mins"},
        //        "classification":[{"main":"","sub":""}],
        //        "created_time":"2016-05-17T01:03:27.453Z",
        //        "creator":"",
        //        "appropriate_gender" : "男",
        //        "max_age" : 10,
        //        "min_age" : 11,
        //        "create_id" :"123",
        //        "tags":["清热去火","高血压"]
        //         }
        //    ],
        //   count : 100

        // }
        self.fillDataFoodList(data.list,flag);
      });
    },
    /*
    * @name {function} 绑定食材列表数据
    * @param {array} objArr 对象的数组
    * @param { number } flag 0:刷新，1:加载更多
    */
    fillDataFoodList :function( objArr,flag ){
      var html = tplCommon.tplFoodList(objArr);
      var $list = $('#js-food-list');
      if( flag == 0 ){
        $list.empty();
      }
      $list.append(html);
    },
    /*
    * @name {function} 获取食材详情数据
    * @param {object} aData 申请应用数据
    * @param {number} no 页码，默认是0
    * @param { number } flag 0:刷新，1:加载更多
    */
    getDataFoodDetails:function(aData,qData,no,flag){
      var self = this,
      url = common.apiHost+'/module/recipes/'+aData.app_id+'/api/ingredient/list',
      data = {
        query : {'_id':{"$in":qData._id}},
        limit:1
      };
      data.offset = parseInt(no||0) * data.limit;
      flag = flag || 0;

      var jsonData = JSON.stringify(data);
      util.appAjax({
        url:url,
        data:jsonData,
        headers:{'Access-Token':aData.access_token}
      }).done(function(data){
        console.info("获取食材详情响应的数据:%o",data);
        // var data =   {
        //    list : [
        //         {
        //        "_id" :"9",
        //        "name":"冬瓜",
        //        "images":["images/pic_002.jpg"],
        //        "instructions":"食材介绍食材介绍", 
        //        "properties":{"cooking_time":"mins"},
        //        "classification":[{"main":"","sub":""}],
        //        "created_time":"2016-05-17T01:03:27.453Z",
        //        "creator":"",
        //        "appropriate_gender" : "男",
        //        "max_age" : 10,
        //        "min_age" : 11,
        //        "create_id" :"123",
        //        "tags":["清热去火","高血压"]
        //         }
        //    ],
        //   count : 100

        // }
        self.fillDataFoodDetails(data.list,flag);
      });
    },
    /*
    * @name {function} 绑定食材列表数据
    * @param {array} objArr 对象的数组
    * @param { number } flag 0:刷新，1:加载更多
    */
    fillDataFoodDetails:function( objArr,flag ){
      var html = tplFood.tplFoodDetails(objArr);
      var $list = $('#js-food-info');
      if( flag == 0 ){
        $list.empty();
      }
      $list.append(html);
    },
     /*
    * @public {function} 获取专家列表数据
    * @param {object} aData 申请应用数据
    * @param {object} qData 查询对象
    * @param {number} no 页码，默认是0
    * @param { number } flag 0:刷新，1:加载更多
    */
    getDataDietitianPicList:function(aData,qData,no,flag){
      var self = this,
      url = common.apiHost+'/module/experts/'+aData.app_id+'/api/experts/list',
      data = {
        limit:2000
      };
      data.offset = parseInt(no||0) * data.limit;
      flag = flag || 0;

      var jsonData = JSON.stringify(data);
      util.appAjax({
        url:url,
        data:jsonData,
        headers:{'Access-Token':aData.access_token}
      }).done(function(data){
        console.info("获取专家头像列表响应的数据:%o",data);
        // var data = {
        //      list : [
        //       {

        //           "_id" : "1",
        //           "user_id" : "123456",
        //           "image" : "images/pic_001.png",
        //           "name" : "吴医生",
        //           "label" : ["敬业1","敬业2"],
        //           "synopsis" : "xxxxxxx",
        //           "isPush" : 1,
        //           "creator" :"123",
        //           "create_time" : "2016-06-15T01:03:27.453Z"
        //       }
        //     ],
        //   count : 100
        // }
        self.fillDataDietitianPicList(data.list,flag);
        self.initSwiperDietitian();
      });
    },
    /*
    * @public {function} 绑定专家列表数据
    * @param {array} objArr 对象的数组
    */
    fillDataDietitianPicList :function( objArr,flag ){
      var html = tplCommon.tplDietitianPicList(objArr);
      var $list = $('#js-dietitian-pic-list');
      if( flag == 0 ){
        $list.empty();
      }
      $list.append(html);
    },
    /*
    * @name {function} 事件绑定
    */
    bindEvents:function(){
      FastClick.attach(document.body);
      $(document).on('tap','.js-btn-back-h5',function(){
        common.back();
      }).on('tap','#keyword',function(){//搜索框获得焦点
        requestHybrid({
          tagname:'forward',
          param:{
            //跳转方式，H5新开Webview跳转，最后装载H5页面
            type:'webview',
            //要去到的页面
            topage:'foodSearch.html'
          },
          callback:function(res){
            //debug && debug.log(res);
          }
        });
      })
    }
  }
  module.exports = Food;
});