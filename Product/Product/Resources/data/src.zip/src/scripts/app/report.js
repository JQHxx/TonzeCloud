define(function(require, exports, module) {
  var Class = require('helper/Class');
  var tplCommon = require('tpl/tplCommon');
  var tplReport = require('tpl/tplReport');
  var FastClick = require('fastclick');
  var util = require('helper/util');
  var Common = require('app/common');
  var common = new Common;
  var Hybrid = require('helper/Hybrid');

  /*
  * @author Qadir
  * @name {class}
  */
  var Report = Class.create();

  Report.prototype = {
    constructor: Report,
    /*
    * @public {function} 初始化
    */
    initialize:function(){
      var self = this
      if(typeof $('#js-report-info').get(0) !=='undefined'){
        common.ajaxAppLoginToken().then(function(lData){
          //报告应用申请凭证
          common.ajaxApplyToken(common.report_appid,lData)
          .then(function(aData){
            //获取报告详情
            self.getDataReportDetails(aData,{'_id':util.queryString('_id')});
          });
        })
      }

      if( typeof $('#js-report-list').get(0) !=='undefined'){
        var rel = $('#js-section-report').find('.tab li.active').attr('data-rel');
        self.tab(rel);
      }
      self.promiseArray = []
      self.bindEvents();
    },
      /*
    * @public {function} 获取报告列表数据
    * @param {object} aData 申请应用数据
    * @param {object} qData 查询对象
    * @param {number} no 页码，默认是0
    * @param { number } flag 0:刷新，1:加载更多
    */
    getDataReportList:function(aData,qData,no,flag){
      var self = this,
      url = common.apiHost+'/module/medicalReport/'+aData.app_id+'/api/medicalReport/list',
      container = '#js-report-list',
      tplKey = 'tplReportList',
      data = $.extend(true,{
        limit: 10,
        order: {
         create_time:-1
        }
      },qData||{});

      data.offset = parseInt(no||0) * data.limit;
      flag = flag || 0;

      var jsonData = JSON.stringify(data);
      util.appAjax({
        url:url,
        data:jsonData,
        headers:{'Access-Token':aData.access_token}
      }).done(function(data){
        console.info("获取报告列表响应的数据:%o",data);
        self.fillDataReportList(container,data.list,flag);
      }).fail(function(xhr, errorType, error){
        console.error(errorType + ':' + error);
      });
    },
    /*
    * @public {function} 绑定报告列表数据
    * @param {string|object} 容器选择器或者选择器对象
    * @param {string} 模板对象的key
    * @param {array} objArr 数据
    * @param { number } flag 0:刷新，1:加载更多
    */
    fillDataReportList:function( container,objArr,flag ){
      var self = this
      rlen = objArr.length
      var $container = $(container);
      var html = tplCommon['tplReportList'](objArr);
      if( flag == 0 ){
        $container.empty();
      }
      $container.parent().find('.list').hide();
      if( !rlen ){
        $('#js-report-no-data').show();
      }else{
         $container.show();
         $('#js-report-no-data').hide();
      }
      $container.append(html);
    },
    /*
    * @public {function} 用户注册一个新的设备
    * @param {object} lData 用户登录数据
    */
    registerDevice:function(lData){
      var url = common.apiHost + '/v2/user/'+lData.user_id+'/register_device'
      data = {
        'product_id':'160fa2ae8575da00160fa2ae8575da01',
        'mac':'000031523962'
      }
      var jsonData = JSON.stringify(data);
      util.appAjax({
        url:url,
        type:'post',
        data:jsonData,
        headers:{'Access-Token':lData.access_token}
      }).done(function(data){
          console.info("用户注册一个新的设备返回的数据:%o",data);
      }).fail(function(xhr, errorType, error){
          console.error(error);
      });
    },
    /*
    * @public {function} 获取用户订阅的设备列表
    * @param {object} lData 用户登录数据
    */
    getDataSubscribe:function(lData,product_id,type){
      var self = this
      var url = common.apiHost + '/v2/user/'+lData.user_id+'/subscribe/devices'
      util.appAjax({
        url:url,
        type:'get',
        headers:{'Access-Token':lData.access_token}
      }).done(function(data){
          //console.info("获取用户订阅的设备列表的数据:%o",data);
          $.each(data,function(i,obj){
            if( product_id == obj.product_id){
              self.getDataDeviceProperty(lData,obj,type);
            }
          });
          $.when.apply($, self.promiseArray).then(function () {
            //console.info("获取设备的扩展属性列表:%o",arguments);
            //debug&&debug.log(arguments);
            self.fillDataClient(arguments,type);
          });
          self.promiseArray = [];
      }).fail(function(xhr, errorType, error){
          console.error(error);
      });
    },
    /*
    * @public {function} 获取设备的扩展属性列表
    * @param {object} dData 设备数据
    */
    getDataDeviceProperty:function(lData,dData){
      var defer = $.Deferred();
      var self = this
      var url = common.apiHost + '/v2/product/'+dData.product_id+'/device/'+dData.id+'/property'
      util.appAjax({
        url:url,
        type:'get',
        headers:{'Access-Token':lData.access_token}
      }).done(function(data){
          //console.info("获取设备的扩展属性列表:%o",data);
          defer.resolve(data);
      }).fail(function(xhr, errorType, error){
          console.error(error);
      });
      self.promiseArray.push(defer);
    },
    /*
    }
    * @public {function} 获取运动列表数据
    * @param {object} aData 申请应用数据
    * @param {object} qData 查询数据
    * @param {number} no 页码，默认是0
    * @param { number } flag 0:刷新，1:加载更多
    */
    getDataReportDetails:function(aData,qData,no,flag){
      var self = this,
      url = common.apiHost+'/module/medicalReport/'+aData.app_id+'/api/medicalReport/list',
      data = {
        query : {'in':{"$in":qData._id}},
        limit:10
      };
      data.offset = parseInt(no||0) * data.limit;
      flag = flag || 0;

      var jsonData = JSON.stringify(data);
      util.appAjax({
        url:url,
        data:jsonData,
        headers:{'Access-Token':aData.access_token}
      }).done(function(data){
        console.info("获取报告详情响应的数据:%o",data);
      //   var data = {
      //      list : [
      //         {
      //       "_id" : "记录ID",
      //       "MachineId":"HST821255555",
      //       "MacAddr":"00-06-55-55-0A-2B",
      //       "RecordNo":"2125555520150409143202",
      //       "MeasureTime":"2015-04-09 14:32:02",
      //       "LoginType":"1",
      //       "DeviceType":"SK-T8",
      //       "UserIcon":"images/pic_002.png",
      //       "Member":{
      //             "Name":"陈XX",
      //             "Mobile":"15811397368",
      //             "IdCode":"440883198909284257",
      //             "Age":"25",
      //             "Sex":"1",
      //             "Address":"广东省XX市",
      //             "Birthday":"1989-09-28",
      //             "Nation":"",
      //             "StartDate":"",
      //             "EndDate":"",
      //             "Department":"",
      //             "BarCode":"",
      //             "IcCode":"",
      //             "SocialCode":"",
      //             "UserID":""
      //           },
      //       "Height":{

      //              "Height":"180",
      //              "Weight":"70",
      //              "BMI":"22",
      //              "IdealWeight":"74",
      //              "Result":"2"
      //           },
      //       "Fat":{
      //           "FatRate":"16",
      //           "Fat":"26.2",
      //           "ExceptFat":"49.8",
      //           "WaterRate":"36.4",
      //           "Water":"26.8",
      //           "Minerals":"1.2",
      //           "Protein":"7.6",
      //           "Fic":"17.8",
      //           "Foc":"9",
      //           "Muscle":"34.4",
      //           "FatAdjust":"-0.3",
      //           "WeightAdjust":"0.1",
      //           "MuscleAdjust":"0.4",
      //           "BasicMetabolism":"1140",
      //           "Viscera":"7",
      //           "Bmc":"3.1",
      //           "MuscleRate":"75.2",
      //           "QuganMuscle":"30.9",
      //           "QuganFat":"8.0",
      //           "ZuotuiMuscle":"9.7",
      //           "ZuobiMuscle":"2.9",
      //           "YoubiMuscle":"3.1",
      //           "YoutuiMuscle":"9.9",
      //           "ZuobiFat":"0.7",
      //           "ZuotuiFat":"3.0",
      //           "YoubiFat":"0.7",
      //           "YoutuiFat":"3.0",
      //           "Result":""
      //           },

      //       "MinFat":{
      //           "Height":"182",
      //           "Weight":"80",
      //           "FatRate":"17",
      //           "BasicMetabolism":"1157",
      //           "Bmi":"24.4",
      //           "Physique":"3",
      //           "Shape":"3",
      //           "Result":"1"
      //         },

      //       "BloodPressure":{
      //           "HighPressure":"96",
      //           "LowPressure":"57",
      //           "Pulse":"65",
      //           "Result":""
      //       },

      //     "Bo":{
      //           "Oxygen":"99",
      //           "OxygenList":"",
      //           "Bpm":"",
      //           "BpmList":"",
      //           "Result":"",
      //           "StartTime":"2015-04-09 14:32:02",
      //           "EndTime":"2015-04-09 14:32:02",
      //           "SecondCount":""
      //       },

      //     "Ecg":{
      //           "Hr":"88",
      //           "EcgData":"",
      //           "nGain":"2",
      //           "Analysis":""
      //        },

      //     "PEEcg":{
      //           "Hr":"",
      //           "PAxis":"",
      //           "QRSAxis":"",
      //           "TAxis":"",
      //           "PR":"",
      //           "QRS":"",
      //           "QT":"",
      //           "QTc":"",
      //           "RV5":"",
      //           "SV1":"",
      //           "EcgData":"",
      //           "EcgImg":"",
      //           "Result":""
      //       },

      //     "Temperature":{
      //           "Temperature":"37",
      //           "Result":"1"
      //       },

      //     "Whr":{
      //           "Waistline":"22",
      //           "Hipline":"88",
      //           "Whr":"25",
      //           "Result":"1"
      //         },

      //     "BloodSugar":{
      //           "BloodSugar":"3.8",
      //           "BloodsugarType":"1",
      //           "Result":"1"
      //       },

      //     "Ua":{
      //           "Ua":"0.54",
      //           "Result":"1"
      //       },

      //     "Chol":{
      //           "Chol":"2.77" ,
      //           "Result":"1"
      //     },

      //     "BloodFat":{
      //           "TChol":"2.77" ,
      //           "HdlChol":"3.56",
      //           "Trig":"4.21",
      //           "CalcLdl":"2.35",
      //           "Result":"1"
      //     },

      //     "Cardiovascular":{
      //           "HeartFunction1":"",
      //           "VascularCondition1":"",
      //           "HeartFunction2":"",
      //           "VascularCondition2":"",
      //           "Result":"",
      //           "SV":"",
      //           "CO":"",
      //           "HOV":"",
      //           "CMBV":"",
      //           "TPR":"",
      //           "PAWP":"",
      //           "N":""
      //           },

      //     "BMD":{
      //           "TSCORE":"2.0",
      //           "ZSCORE":"2.2",
      //           "OI":"",
      //           "BQI":"",
      //           "SOS":"300",
      //           "YOUNG_ADULT":"",
      //           "AGE_MATCHED":"",
      //           "BUA":"",
      //           "EOA":"",
      //           "RRF":"",
      //           "PAB":"",
      //           "Result":""
      //        },

      //      "Hb":{
      //           "Hb":"5.0",
      //           "Hct":"6.0",
      //           "Result":"0"
      //       },

      //     "Alcohol":{
      //           "Alcohol":"2.0",
      //           "Result":"0"
      //       },
      //      "create_time" : "2016-06-15T01:03:27.453Z"
      //     }
      //     ],
      //   count : 100
      // }
      self.fillDataReportDetails(data.list,flag);
      });
    },
    /*
    * @public {function} 绑定报告列表数据
    * @param {array} objArr 对象的数组
    * @param { number } flag 0:刷新，1:加载更多
    */
    fillDataReportDetails:function( objArr,flag ){
      var html = tplReport.tplReportDetails(objArr);
      var $info = $('#js-report-info');
      if( flag == 0 ){
        $info.empty();
      }
      $info.append(html);
    },
     /*
    * @public {function} 绑定客户端数据
    * @param {array}  objArr 对象数组
    */
    fillDataClient:function(objArr,type){
      var html = ''
      var tplKey = 'tplReportBloodPressure'
      var dataKey = 'measurements'
      var flag = false
      switch(type){
        case 'bloodPressure':
          tplKey = 'tplReportBloodPressure';
        break;
        case 'temperature':
          tplKey = 'tplReportTemperature';
        break;
        case 'minFat':
          tplKey = 'tplReportMinFat';
          // objArr = [{
          //    mac : "20:91:48:66:41:FC",
          //    list:[{
          //     name:"hhhu",
          //     bmi : "11.5",
          //     bmr : "0.0",
          //     bodyfat : "0.0",
          //     bone : "0.0",
          //     creatTime : 1473044427178,
          //     day : 05,
          //     hour : 11,
          //     id : 1,
          //     "measure_time" : "2016-09-05 11:00:00",
          //     minute : 00,
          //     month : 09,
          //     muscle : "0.0",
          //     protein : "0.0",
          //     second : 27,
          //     sign : "{\"water\":false,\"bmr\":false,\"bone\":false,\"protein\":false,\"muscle\":false,\"bodyfat\":false,\"visfat\":false,\"subfat\":false,\"bmi\":\"\U504f\U4f4e\"}",
          //     subfat : "0.0",
          //     unit : 'kg',
          //     visfat : 0,
          //     water : "0.0",
          //     weight : "46.00",
          //     year : 2016
          //   }],
          //   name:'体脂称'
          // }]
        break;
      }
      var $container = $('#js-section-report .list[data-rel="'+ type +'"]')
      $container.parent().find('.list').hide();
      $container.empty();

      $.each(objArr,function(i,obj){
        var dataArr = obj[dataKey]||[];
        var dataArrLen = dataArr.length;
        if( dataArrLen ){
          flag = true;
          html = tplReport[tplKey](obj);
          $container.append(html)
        }
      })
      if( flag ){
        $container.show();
        $('#js-report-no-data').hide();
      }else{
        $('#js-report-no-data').show();
      }

    },
    /*
    * @public {function} tab切换
    * @param {string} rel 标识
    */
    tab:function( rel ){
      var rel = rel ||'all'
      var self = this
      var $container = $('#js-report-list')
      $container.parent().find('.list').hide();
      $container.parent().find('.list').filter('[data-rel="'+rel+'"]').show();

      switch(rel){
        case 'all'://全科体验
          common.ajaxAppLoginToken().then(function(lData){
            //报告应用申请凭证
            common.ajaxApplyToken(common.report_appid,lData)
            .then(function(aData){
              if( typeof $('#js-report-list').get(0) !=='undefined'){
                //获取报告列表
                self.getDataReportList(aData);
              }
            });
          });
        break;
        case 'bloodPressure'://血压监测
          common.ajaxAppLoginToken().then(function(lData){
            //获取用户订阅的设备列表
            self.getDataSubscribe(lData,common.product_id_bloodPressure,rel)
          });
        break;
        case 'temperature'://体温监测
          common.ajaxAppLoginToken().then(function(lData){
            //获取用户订阅的设备列表
            self.getDataSubscribe(lData,common.product_id_temperature,rel)
          });
         break;
        case 'minFat'://体质分析
           common.ajaxAppLoginToken().then(function(lData){
              //获取用户订阅的设备列表
            self.getDataSubscribe(lData,common.product_id_minFat,rel)
           });
        break;
      }
    },
     /*
    * @public {function} bindEvents 事件绑定
    */
    bindEvents:function(){
      FastClick.attach(document.body);
      var self = this;
      $(document).on('tap','#js-section-report .tab li',function(){//tab切换
        var rel = $(this).attr('data-rel');
        if($(this).hasClass('active')) return;
        $(this).parent().children().removeClass('active');
        $(this).addClass('active');
        self.tab(rel);
      }).on('click','.js-btn-back-h5',function(){//后退
        common.back();
      })
    }
  }
  module.exports = Report;
});