define(function(require, exports, module) {
  var Class = require('helper/Class');
  var tplCommon = require('tpl/tplCommon');
  var tplMenu = require('tpl/tplMenu');
  var FastClick = require('fastclick');
  var util = require('helper/util');
  var Common = require('app/common');
  var common = new Common;
  var Hybrid = require('helper/Hybrid');

  require('plugins/swiper.jquery');
  /*
  * @author Qadir
  * @name {class} 菜谱
  */
  var Menu = Class.create();

  Menu.prototype = {
    constructor: Menu,
    /*
    * @name {function} 初始化
    */
    initialize:function(){
      var self = this
      common.ajaxAppLoginToken().then(function(lData){
        common.ajaxUserProperty(lData).then(function(pData){
          self.getDataUserProperty(lData,pData);
        });
      })
      self._menuInfo = null;
      self._orderTime = null;
      window['orderTimePickerResult'] = function(res){
        //debug&&debug.log(res)
        if( res.Status == 200 ){
          self._orderTime = [res.hour,res.min];
          requestHybrid({
            tagname:'getFreeDeviceArray',
            callback:function(res){
              self.fillDataCookingList(res.devices);
            }
          });
        }
      }
      console.log(self.orderTime2startTime([19,20]));
      self.bindEvents();
    },
    /*
    * @name {function} 轮播图初始化
    */
    initSwiperMenu:function(){
      var $swiperContainer = $('#js-menu-swiper-container');
      if( typeof $swiperContainer.get(0) == 'undefined') return;
      $swiperContainer.swiper({
        autoplay:5000,
        autoplayDisableOnInteraction:false,
        pagination: '.swiper-pagination',
        paginationClickable: true,
        loop:true
      })
    },
     /*
    * @name {function} 切换营养专家初始化
    */
    initSwiperDietitian:function(){
      var $swiperContainer = $('#js-dietitian-swiper-container');
      if( typeof $swiperContainer.get(0) == 'undefined') return;
      $swiperContainer.swiper({
        slidesPerView: 4.5,
        spaceBetween: 15
      })
    },
     /*
    * @name {function} 获取用户属性
    * @param {object} lData 登陆用户数据
    * @param {object} pData 用户属性数据
    */
    getDataUserProperty:function(lData,pData){
      var self = this;
      if(pData.label){//有标签
           //专家应用申请凭证
          common.ajaxApplyToken(common.dietitian_appid,lData)
          .then(function(aData){
            //获取专家头像列表
            self.getDataDietitianPicList(aData,pData);
          });
          //菜谱应用申请凭证
          common.ajaxApplyToken(common.menu_appid,lData)
          .then(function(aData){
            //获取菜谱详情
            self.getDataMenuDetails(aData,{'_id':util.queryString('_id')});
          });
      }
    },
     /*
    * @public {function} 获取菜谱详情数据
    * @param {object} aData 申请应用数据
    * @param {object} qData 查询数据
    */
    getDataMenuDetails:function(aData,qData){
      var self = this,
      url = common.apiHost+'/module/recipes/'+aData.app_id+'/api/recipes/list',
      data = {
        query : {'_id':{'$in':[qData._id]}}
      };
      var jsonData = JSON.stringify(data);
      util.appAjax({
        url:url,
        data:jsonData,
        headers:{'Access-Token':aData.access_token}
      }).done(function(data){
        console.info("获取菜谱详情响应的数据:%o",data);
        // var data = {
        //     "count":1,
        //     "list":[
        //     {"_id":"57833aa002de139b1271fbf4",
        //     "name":"西洋菜瘦肉汤",
        //     "instructions":
        //     "此款汤水甘甜滋润，具有清热泻火、润肺止咳之功效。特别适宜热气兼有感冒、喉痛、咳嗽者饮用。",
        //     "properties":{"symptom":[{"name":"糖尿病","id":2}],"difficulty":"不限"},
        //     "tips":"西洋菜可换成白菜，适合一般人群饮用。",
        //     "creator":"vip@tonze.com",
        //     "create_time":"2016-07-11T14:20:16.701Z",
        //     "__v1":0,
        //     "appropriate_gender":"男",
        //     "max_age":25,
        //     "min_age":19,
        //     "tags":["维生素C"],
        //     "devices":[{
        //       "buy_link":"http://cn.vuejs.org/api/",
        //       "time":"40分钟","tips":["","",""],
        //       "autoexec":"03 01 64 50 01 00 04 32 64 00 28 03 14 42 18 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00",
        //       "name":"隔水炖","id":2}],
        //       "cooking_steps":[
        //       {"images":["http://xlink-tj.oss-cn-hangzhou.aliyuncs.com/d2f4a2d1f60802362063da1497e4450f"],
        //       "time":"","description":"准备好所有材料，将西洋菜去掉根部后洗净，200克重量为去掉根部重量。猪瘦肉洗净后，切成小块状。"},
        //       {"images":["http://xlink-tj.oss-cn-hangzhou.aliyuncs.com/40c224be2a867e69ee694b81457f605e"],
        //       "time":0,"description":"将瘦肉、西洋菜、蜜枣放入隔水炖盅内，加约800ML清水并加入适量食用油，炖煮40分钟。"},
        //       {"images":["http://xlink-tj.oss-cn-hangzhou.aliyuncs.com/7e91744289e80bbcb60afa777d082f1f"],"time":0,"description":"食用前加盐调味即可。"}],
        //       "classification":[{"sub":[],"main":"一般人群"}],
        //       "minor_ingredients":[],
        //       "major_ingredients":[
        //       {"unit":"200克","name":"西洋菜","classification":[{"sub":[],"main":"蔬菜类"}],"_id":"577ca1d102de139b1271fbf3"},
        //       {"unit":"350克","name":"瘦肉","classification":[{"sub":[],"main":"畜乳类"}],"_id":"577ca1b1ddc4fc5412643407"},
        //       {"unit":"3粒","name":"蜜枣","classification":[{"main":"水果类","sub":[]}],"_id":"577ca420357732be127c6a5a"},
        //       {"unit":"适量","name":"盐","classification":[{"main":"调味类","sub":[]}],"_id":"577ca44512b3e06912829bfe"},
        //       {"unit":"适量","name":"花生油","classification":[{"main":"调味类","sub":[]}],"_id":"577ca45e6aa3587d12eca405"},
        //       {"_id":"578340a8e142ccc312fffb68","classification":[{"sub":[],"main":"调味类"}],"name":"鸡精","unit":"适量"}],
        //       "images":["http://xlink-tj.oss-cn-hangzhou.aliyuncs.com/2bfca07cf8f29912ab810d56b1bc04d5"]
        //     }
        //     ]
        //   }
        self.fillDataMenuDetails(data.list);
        self.initSwiperMenu();
        if( data.list[0] )
          self._menuInfo = data.list[0]
      });
    },
    /*
    * @public {function} 绑定菜谱详情数据
    * @param {array} objArr 对象的数组
    */
    fillDataMenuDetails :function( objArr ){
      var html = tplMenu.tplMenuDetails(objArr);
      var $menuInfo = $('#js-menu-info');
      $menuInfo.empty().append(html);
    },
     /*
    * @public {function} 获取专家头像列表数据
    * @param {object} aData 申请应用数据
    * @param {object} qData 查询对象
    * @param {number} no 页码，默认是0
    * @param { number } flag 0:刷新，1:加载更多
    */
    getDataDietitianPicList:function(aData,qData,no,flag){
      var self = this,
      url = common.apiHost+'/module/experts/'+aData.app_id+'/api/experts/list',
      data = {
        query : {'label':{"$in":qData.label}},
        limit:2000
      };
      data.offset = parseInt(no||0) * data.limit;
      flag = flag || 0;

      var jsonData = JSON.stringify(data);
      util.appAjax({
        url:url,
        data:jsonData,
        headers:{'Access-Token':aData.access_token}
      }).done(function(data){
        console.info("获取专家列表数据响应的数据:%o",data);
        // var data = {
        //      list : [
        //       {

        //           "_id" : "1",
        //           "user_id" : "123456",
        //           "image" : "images/pic_001.png",
        //           "name" : "吴医生",
        //           "label" : ["敬业1","敬业2"],
        //           "synopsis" : "xxxxxxx",
        //           "isPush" : 1,
        //           "creator" :"123",
        //           "create_time" : "2016-06-15T01:03:27.453Z"
        //       }
        //     ],
        //   count : 100
        // }
        self.fillDataDietitianPicList(data.list,flag);
        self.initSwiperDietitian();
      }).fail(function(xhr,errorType,error){
        console.error(errorType+': '+error);
        self.initSwiperDietitian();
      });
    },
    /*
    * @public {function} 绑定专家头像列表数据
    * @param {array} objArr 对象的数组
    */
    fillDataDietitianPicList :function( objArr,flag ){
      var html = tplCommon.tplDietitianPicList(objArr);
      var $list = $('#js-dietitian-pic-list');
      if( flag == 0 ){
        $list.empty();
      }
      $list.append(html);
    },
    /*
    * @public {function} 绑定厨具列表数据
    * @param {array} objArr 对象的数组
    */
    fillDataCookingList:function(objArr,type){
      var type = type ||'start';
      var $muiDialogCooking = $('#js-mui-dialog-cooking')
      var len = objArr.length
      var $container =  $muiDialogCooking.find('.cooking-list')
      var html = ''
      if( !len ){
        util.tips('暂无设备');
        return;
      }
      $muiDialogCooking.show();
      $.each(objArr,function(i,obj){
        obj.type = type;
      })
      html = tplMenu.tplCookingList(objArr);
      $container.empty().append(html);
    },
    /*
    * @public {function} 预约时间转启动时间
    * @param {array} orderTime 预约时间,[小时,分钟]
    * @return {array} 启动时间,[小时,分钟]
    */
    orderTime2startTime:function(orderTime){
      if( !orderTime ){
        return [0,0];
      }
      //预约小时
      var oHour = parseInt(orderTime[0]);
      //预约分钟
      var oMin = parseInt(orderTime[1]);
      //预约毫秒
      var oMs = oHour*36e5 + oMin*6e4;
      var date = new Date();
      //当前小时
      var cHour = date.getHours();
       //当前分钟
      var cMin = date.getMinutes();
      //当前毫秒
      var cMs = (cHour*3600 + cMin*60)*1000;

      var tObj = {}

      if( oMs >= cMs ){
        tObj = util.ms2hms(oMs - cMs );
        return [tObj.hour,tObj.min]
      }else{
        tObj = util.ms2hms(24*36e5 - cMs + oMs );
        return [tObj.hour,tObj.min]
      }
    },
    /*
    * @public {function} 拼接厨具参数
    * @param {array} objArr 对象的数组
    */
    joinCookingParam:function(menuName,mac,deviceType,type){
      var self = this
      var menuInfo = self._menuInfo;
      if( !menuInfo ) return '';
      var arrObj = {};
      var base64arr = [];
      var menuName = menuName;
      var autoexec = '';
      var autoexecArr = [];
      var base64 = '';
      $.each(menuInfo.devices,function(i,obj){
        if( obj.id == deviceType ){
          autoexec = obj.autoexec;
          return false;
        }
      })

      if( type == 'preference' ){
        // 固定的
        arrObj.fixedArr = ['0x13','0x00','0x00'];
        //设备代码
        arrObj.deviceCodeArr = [{"0": "0x10","1": "0x05","2": "0x05","3": "0x05"}[deviceType||0]];
      }else{
        //固定
        arrObj.fixedArr = ['0x14','0x00','0x00'];
        //设备代码
        arrObj.deviceCodeArr = [{ "0": "0x0e","1": "0x08","2": "0x08","3": "0x07"}[deviceType||0]];
        //启动时间 [小时,分钟]
        arrObj.timeArr = self.orderTime2startTime(self._orderTime);
      };
       //菜谱名字的ascii码
      arrObj.menuNameArr = util.to16(util.base64decode(menuName));
       //烹饪代码
      autoexecArr = autoexec.split(' ');
      //转16进制
      $.each(autoexecArr,function(i,item){
        autoexecArr[i] = '0x'+ item;
      })
      arrObj.autoexecArr = autoexecArr;

      //debug&&debug.log('固定位:'+ arrObj.fixedArr);
      //debug&&debug.log('设备位:'+ arrObj.deviceCodeArr)
      //debug&&debug.log('预约时间：'+ self._orderTime);
      //debug&&debug.log('启动时间:'+ arrObj.timeArr)
      //debug&&debug.log('菜谱名位:'+ arrObj.menuNameArr)
      //debug&&debug.log('控制位:'+ arrObj.autoexecArr)

      for( var k in arrObj){
        if(k){
          base64arr = base64arr.concat(arrObj[k]);
        }
      }

      //debug&&debug.log('合并后的数组：'+ base64arr);

      base64 = util.base64encode(base64arr);

      //debug&&debug.log( mac + '?' + base64);

      requestHybrid({
        tagname:'sendWIFIDeviceData',
        param: mac + '?' + base64,
        callback:function(res){
          //debug&&debug.log(res);
        }
      });

    },
    controlCooking:function(mac,deviceType,type){
      var self = this
      var menuInfo = self._menuInfo;
      if( !menuInfo ) return '';
      //菜谱名称
      var menuName = menuInfo.name;
      requestHybrid({
          tagname:'getNameAsciiCode',
          param:menuName,
          callback:function(res){
            if(res.Status == 200){
              self.joinCookingParam(res.data,mac,deviceType,type)
            }
          }
      });
    },
    /*
    * @name {function} 事件绑定
    */
    bindEvents:function(){
      var self = this;
      FastClick.attach(document.body);
      $(document).on('click','.js-unfold a',function(){//展开全部
        $(this).parent().prev().removeClass('packup');
        $(this).parent().hide();
      }).on('tap','.js-btn-back-h5',function(){//后退
        common.back();
      }).on('tap','#js-instant-on',function(){//调用app接口-立即启动设备
        requestHybrid({
          tagname:'getFreeDeviceArray',
          callback:function(res){
            self.fillDataCookingList(res.devices,'start');
          }
        });
      }).on('tap','#js-precontract',function(){//调用app接口-预约启动设备
        requestHybrid({
          tagname:'showOrderTimePicker',
          callback:function(res){
            //debug&&debug.log(res);
          }
        })
      }).on('tap','#js-preference',function(){//调用app接口-设为偏好
        requestHybrid({
          tagname:'getFreeDeviceArray',
          callback:function(res){
            self.fillDataCookingList(res.devices,'preference');
          }
        });
      }).on('tap','#js-mui-dialog-cooking .cooking-list li',function(){//调用app接口-控制设备工作
        var mac = $(this).attr('data-mac');
        var deviceId = $(this).attr('data-id');
        var type = $(this).attr('data-type');
        //debug&&debug.log('操作方式：'+ type);
        self.controlCooking(mac,deviceId,type);
        $('#js-mui-dialog-cooking').hide();

      }).on('tap','#js-mui-dialog-cooking .mui_mask',function(){
        $('#js-mui-dialog-cooking').hide();
      })
    }
  }
  module.exports = Menu;
});