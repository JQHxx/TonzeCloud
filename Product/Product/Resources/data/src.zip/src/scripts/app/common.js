define(function(require, exports, module) {
  var Class = require('helper/Class');
  var util = require('helper/util');
  var tplCommon = require('tpl/tplCommon');
  var Hybrid = require('helper/Hybrid');
  var FastClick = require('fastclick');
  /*
  * @author Qadir
  * @name {class} 通用业务类
  */
  var Common = Class.create();

  Common.prototype = {
    constructor: Common,
    /*
    * @public {function} 初始化
    */
    initialize:function(){
      this.apiHost = 'https://dev-man.360tj.com:8016';
      //菜谱管理appid
      this.menu_appid = '2e0fa2ae97450e00';
      //专家管理appid
      this.dietitian_appid = '2e07d2af6d51e200';
      //健康数据appid
      this.report_appid = '2e07d2af9c380000';
      //内容管理appid
      this.content_appid = '2e07d2af8fe30c00';
      //运营位管理appid
      this.operate_appid = '2e07d2af9c387400';

      //历史搜索缓存的key
      this.history_cache = 'history_cache';
      //筛选条件缓存的key
      this.filter_cache = 'filter_cache';
      //血压计
      this.product_id_bloodPressure = '160fa2ae8575da00160fa2ae8575da01';
       //体温计
      this.product_id_temperature = '160fa2ae85778a00160fa2ae85778a01';
      //体脂秤
      this.product_id_minFat = '160fa2ae8aea0200160fa2ae8aea0201';

      //筛选条件
      this.filter_condition = {
        //症状
        'symptom':[{ name:'高血压',status:!1 },
        { name:'高血糖',status:!1 },{ name:'高血脂',status:!1 },
        { name:'高尿酸',status:!1 },{ name:'低血氧',status:!1 }],
        //性别
        'sex':[{name:'男',status:!1},{name:'女',status:!1}],
        //年龄
        'age':[{'name':'1-10岁',status:!1},{'name':'11-18岁',status:!1},
        {'name':'19-25岁',status:!1},{'name':'26-35岁',status:!1},
        {'name':'36-59岁',status:!1},{'name':'60岁以上',status:!1}]
      }

      this.bindEvents();

      this.debug = false;

      if( this.debug ){
        $('body').append('<div class="app-debug" id="js-btn-ref"><a class="btn-ref">刷新页面</a></div>');
        $(document).on('click','#js-btn-ref',function(){
          var url = window.location.href;//获取当前url
          var searchUrl = util.setParam("v",+new Date());
          if(url.indexOf("?")>0){
              url = url.split("?")[0];
          }
          window.location.href=url+searchUrl;
        })
      }
    },
    /*
    * @public {function} 获取app登陆token
    * @return {promise} promise对象
    */
    ajaxAppLoginToken:function(){
      var defer = $.Deferred();
      var user_cache = util.getItem('user_cache');
      if( user_cache ){//有效
        console.info("app登陆token缓存数据:%o",user_cache);
        defer.resolve(user_cache);
      }else{//失效
        util.removeItem('user_cache');
        util.removeItem('apply_token_' + this.menu_appid);
        util.removeItem('apply_token_' + this.dietitian_appid);
        util.removeItem('apply_token_' + this.report_appid);
        util.removeItem('apply_token_' + this.content_appid);
        util.removeItem('apply_token_' + this.operate_appid);

        // var self = this,
        // url = self.apiHost +'/v2/user_auth',
        // data = {
        //   "corp_id":"100fa2ad4bf29a00",
        //   "phone":"18664896191",
        //   "password":"xx123456"
        // };
        // var jsonData = JSON.stringify(data);
        // util.appAjax({
        //   url:url,
        //   data:jsonData
        // }).done(function(data){
        //   console.info("app登陆token接口返回的数据:%o",data);
        //   //util.setItem('user_cache',data,0.5);
        //   defer.resolve(data);
        // }).fail(function(xhr, errorType, error){
        //   console.error(error);
        // });
        requestHybrid({
          tagname:'getAccessToken',
          callback:function(res){
            if( res.Status == 200 ){
              defer.resolve(res.userInfo);
            }else{
              self.polling(arguments.callee,1);
            }
            //debug&&debug.log(res);
          }
        });
      }
      return defer.promise();
    },
     /*
    * @public {function} 轮询
    * @param {function} fn 轮询的方法
    * @param {number} count 轮询的次数
    */
    polling:function(fn,count){
      var count = count||1;
      var i = 0;
      var timer = null;
      timer = setInterval(function(){
        if( i < count){
          i++;
          fn && fn();
        }else{
          clearInterval(timer);
        }
      },500);
    },
    /*
    * @public {function} 申请应用接口调用凭证
    * @param {string} appId 申请应用的appId
    * @param {object} lData 用户登陆的数据
    * @return {promise} promise对象
    */
    ajaxApplyToken:function(appId,lData){
      var defer = $.Deferred();
      var apply_token = util.getItem('apply_token_' + appId);
      if( apply_token ){//有效
        console.info("申请应用token缓存数据:%o",apply_token);
        defer.resolve(apply_token);
      }else{//失效
        var self = this,
        url = self.apiHost +'/v2/plugin/apply_token',
        data = {
          "app_id":appId
        };
        var jsonData = JSON.stringify(data);
        util.appAjax({
          url:url,
          data:jsonData,
          headers:{'Access-Token':lData.access_token}
        }).done(function(data){
          console.info("申请应用接口成功返回的数据:%o",data);
          defer.resolve(data);
          util.setItem('apply_token_' + appId,data,1);
        }).fail(function(xhr, errorType, error){
          console.error(error);
        });
      }
      return defer.promise();
    },
    /*
    * @public {function} 获取用户属性
    * @param {object} lData 用户登陆数据
    */
    ajaxUserProperty:function(lData){
      var defer = $.Deferred();
      var self = this;
      var user_label = util.getItem('user_label');
      if( user_label ){
        console.info("用户属性缓存数据:%o",user_label);
        defer.resolve(user_label);
      }else{
        var url = self.apiHost+'/v2/user/'+lData.user_id+'/property';
        util.appAjax({
          url:url,
          type:'get',
          headers:{'Access-Token':lData.access_token}
        }).done(function(data){
          console.info("获取用户属性响应的数据:%o",data);
          if(data.label){//有标签
            defer.resolve(data);
            //缓存用户标签，长期
            util.setItem('user_label',data,24*30*12);
          }else{
            defer.resolve(null);
          }
        }).fail(function(xhr, errorType, error){
          console.error(error);
          defer.resolve(null);
        });
      }
      return defer.promise();
    },
      /*
    * @public {function} 获取列表数据
    * @param {object} aData 申请应用数据
    * @param {object} qData 查询对象
    * @param {number} no 页码，默认是0
    * @param { number } flag 0:刷新，1:加载更多
    */
    getDataList:function(aData,qData,no,flag,cb){
      var self = this,
      url = '',
      container = '',
      tplKey = '',
      info = ''
      data = $.extend(true,{
        limit: 10,
        order:{
          create_time:-1
       }
      },qData||{});
      data.offset = parseInt(no||0) * data.limit;
      flag = flag || 0;

      switch(aData.app_id){
          case self.dietitian_appid:
            url = self.apiHost+'/module/experts/'+aData.app_id+'/api/experts/list';
            container = '#js-dietitian-list';
            tplKey = 'tplDietitianList';
            info = '专家';
          break;
          case self.content_appid:
            url = self.apiHost+'/module/contents/'+aData.app_id+'/api/article/list';
            container = '#js-sports-list';
            tplKey = 'tplSportsList';
            info = '运动';
          break;
          case self.menu_appid:
           url = self.apiHost+'/module/recipes/'+aData.app_id+'/api/recipes/list';
           container = '#js-menu-list';
           tplKey = 'tplMenuList';
           info = '菜谱';
          break;
      }
      var jsonData = JSON.stringify(data);
      util.appAjax({
        url:url,
        data:jsonData,
        headers:{'Access-Token':aData.access_token}
      }).done(function(data){
        console.info("获取"+info+"列表响应的数据:%o",data);
        if(!cb){
           self.fillDataList(container,tplKey,data.list,flag);
        }else{
          cb(data.list,flag)
        }
      }).fail(function(xhr, errorType, error){
        console.error(errorType + ':' + error);
      });
    },
    /*
    * @public {function} 绑定列表数据
    * @param {string|object} 容器选择器或者选择器对象
    * @param {string} 模板对象的key
    * @param {array} objArr 数据
    * @param { number } flag 0:刷新，1:加载更多
    */
    fillDataList:function( container,tplKey,objArr,flag ){
      var self = this
      rlen = objArr.length
      var $container = $(container);
      var html = tplCommon[tplKey](objArr);
      if( flag == 0 ){
        $container.empty();
      }
      if( !rlen ){
        html ='<p class="no-result">暂无结果</>'
      }
      $container.append(html);
    },
    back:function(){
      return history.go(-1);
    },
    /*
    * @public {function} 事件绑定
    */
    bindEvents:function(){
      FastClick.attach(document.body);
      $(document).on('tap','.js-btn-personal',function(){//调用app接口-个人中心
        requestHybrid({
          tagname:'clickLeftButton',
          callback:function(res){
            //debug&&debug.log(res);
          }
        });
      }).on('tap','.js-btn-add',function(){//调用app接口-添加设备
        requestHybrid({
          tagname:'clickAddDevie',
          callback:function(res){
            //debug&&debug.log(res);
          }
        });
      })
    }
  }

  module.exports = Common;
});