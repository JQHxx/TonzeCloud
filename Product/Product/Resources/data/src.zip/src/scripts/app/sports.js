define(function(require, exports, module) {
  var Class = require('helper/Class');
  var tplCommon = require('tpl/tplCommon');
  var tplSports = require('tpl/tplSports');
  var FastClick = require('fastclick');
  var util = require('helper/util');
  var Common = require('app/common');
  var common = new Common;
  /*
  * @author Qadir
  * @name {class} 营养专家
  */
  var Sports = Class.create();

  Sports.prototype = {
    constructor: Sports,
    /*
    * @name {function} 初始化
    */
    initialize:function(){
      var self = this
      common.ajaxAppLoginToken().then(function(lData){
        common.ajaxUserProperty(lData).then(function(pData){
          self.getDataUserProperty(lData,pData);
        });
      })
       $('#js-search #keyword').focus();
      self.bindEvents();
    },
    /*
    * @name {function} 获取用户属性
    * @param {object} lData 登陆用户数据
    * @param {object} pData 用户属性数据
    */
    getDataUserProperty:function(lData,pData){
      var self = this;
      if(pData.label){//有标签
           //专家应用申请凭证
          common.ajaxApplyToken(common.dietitian_appid,lData)
          .then(function(aData){
            if( typeof $('#js-dietitian-list').get(0) !== 'undefined' ){
              var condition = {
                query : {'label':{"$in":pData.label}},
                limit:1
              };
              //获取专家列表
              common.getDataList(aData,condition);
            }

          });
          //运动应用申请凭证
          common.ajaxApplyToken(common.content_appid,lData)
          .then(function(aData){
            if( typeof $('#js-sports-list').get(0) !=='undefined'){
              var condition = {
                  query : {'label':{"$in":pData.label}}
              };
              common.getDataList(aData,condition,0,0,function(objArr,flag){
                self.fillDataDietitianList(objArr,flag)
              });
            }
            if(typeof $('#js-sports-info').get(0) !=='undefined'){
              self.getDataSportsDetails(aData,{'_id':util.queryString('_id')});
            }
          });
      }
    },
    /*
    * @public {function} 绑定专家列表数据
    * @param {array} objArr 对象的数组
    */
    fillDataFoodList :function( objArr,flag ){
      var self = this
      var html = tplCommon.tplDietitianList(objArr);
      var $list = $('#js-dietitian-list');
      if( flag == 0 ){
        $list.empty();
      }
      $list.append(html);

      var $muiDialogFilter = $('#js-mui-dialog-filter')
      if( typeof $muiDialogFilter.get(0) === 'undefined'  ) return;

      var arr = [],oArr = [],key_obj = {}
      $.each(objArr,function(i,obj){
        $.each(obj.label,function(j,item){
          arr.push(item);
        })
      })
      //去重
      arr = util.unique(arr);
      $.each(arr,function(k,item){
        var obj = {}
        obj.name = item;
        obj.status = !1;
        oArr.push( obj );
      })
      $.each(self.keyArr,function(i,item){
        key_obj[item] = oArr;
      })
      self.setCacheFilter(key_obj);
    },

     /*
    * @name {function} 获取运动详情数据
    * @param {object} aData 申请应用数据
    * @param {object} qData 查询数据
    * @param {number} no 页码，默认是0
    * @param { number } flag 0:刷新，1:加载更多
    */
    getDataSportsDetails:function(aData,qData,no,flag){
      var self = this,
      url = common.apiHost+'/module/contents/'+aData.app_id+'/api/article/list',
      data = {
        query : {'_id':{"$in":qData._id}},
        limit:1
      };
      data.offset = parseInt(no||0) * data.limit;
      flag = flag || 0;

      var jsonData = JSON.stringify(data);
      util.appAjax({
        url:url,
        data:jsonData,
        headers:{'Access-Token':aData.access_token}
      }).done(function(data){
        console.info("获取运动响应的数据:%o",data);
        // var data =  {
        //      list : [
        //       {
        //         _id : "3",
        //         name: "四月水果当季尝",
        //         label : ["文章1","文章2"],
        //         images:["images/pic_002.jpg"],
        //         pageviews : 133392,
        //         text :  "文本内容文本内容文本内容文本内容",
        //         status : 0,
        //         creator : "小明",
        //         create_time :"2016-05-17T01:03:27.453Z",
        //         appropriate_gender : "男",
        //         create_id :"123",
        //         max_age : 10,
        //         min_age : 11
        //       }
        //     ],
        //   count : 100
        // }
        self.fillDataSportsDetails(data.list,flag);
      })
    },
    /*
    * @name {function} 绑定运动详情数据
    * @param {array} objArr 对象的数组
    * @param { number } flag 0:刷新，1:加载更多
    */
    fillDataSportsDetails :function( objArr,flag ){
      var html = tplSports.tplSportsDetails(objArr);
      var $info = $('#js-sports-info');
      if( flag == 0 ){
        $info.empty();
      }
      $info.append(html);
    },
    /*
    * @name {function} 事件绑定
    */
    bindEvents:function(){
      FastClick.attach(document.body);
      $(document).on('tap','.js-btn-back-h5',function(){
        common.back();
      }).on('tap','#keyword',function(){//搜索框获得焦点
        requestHybrid({
          tagname:'forward',
          param:{
            //跳转方式，H5新开Webview跳转，最后装载H5页面
            type:'webview',
            //要去到的页面
            topage:'sportsSearch.html'
          },
          callback:function(res){
            //debug&&debug.log(res);
          }
        });
      })
    }
  }
  module.exports = Sports;
});