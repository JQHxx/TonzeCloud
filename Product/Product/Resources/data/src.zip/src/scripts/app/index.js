define(function(require, exports, module) {
  var Class = require('helper/Class');
  var tplIndex = require('tpl/tplIndex');
  var tplCommon = require('tpl/tplCommon');
  var FastClick = require('fastclick');
  var util = require('helper/util');
  var Common = require('app/common');
  var common = new Common;
  var Hybrid = require('helper/Hybrid');
  require('plugins/swiper.jquery');

  /*
  * @author Qadir
  * @public {class} 首页业务类
  */
  var Index = Class.create();

  Index.prototype = {

    constructor: Index,
    /*
    * @public {function} 初始化
    */
    initialize:function(){
      var self = this
      common.ajaxAppLoginToken().then(function(lData){
        common.ajaxUserProperty(lData).then(function(pData){
          self.getDataUserProperty(lData,pData);
        });
      })
      self.fillDataSwiperList([{
        images:[
        "images/banner/banner640.480.01.png",
        "images/banner/banner640.480.02.png",
        "images/banner/banner640.480.03.png",
        "images/banner/banner640.480.04.png",
        "images/banner/banner640.480.05.png"
        ]
      }]);
      self.initSwiper();
      self.bindEvents();
    },
    /*
    * @public {function} 轮播图初始化
    */
    initSwiper:function(){
      var $swiperContainer = $('#js-section-swiper-container .swiper-container');
      if( typeof $swiperContainer.get(0) == 'undefined') return;
      $swiperContainer.swiper({
        autoplay:5000,
        autoplayDisableOnInteraction:false,
        pagination: '.swiper-pagination',
        paginationClickable: true,
        loop:true
      })
    },

     /*
    * @public {function} 获取轮播图列表数据
    * @param {object} aData 申请应用数据
    * @param {object} qData 查询数据
    * @param {object} oData 运营位ID数据
    */
    getDataSwiperList:function(aData,qData,oData){
      var _id = oData.list[0]._id;
      var self = this,
      url = common.apiHost+'/module/operatePosition/'+aData.app_id+'/api/content/list',
      data = {
        query : {'label':{"$in":qData.label},'_id':{"$in":_id }},
        limit:5
      };
      var jsonData = JSON.stringify(data);
      util.appAjax({
        url:url,
        data:jsonData,
        headers:{'Access-Token':aData.access_token}
      }).done(function(data){
        console.info("获取轮播图列表数据响应的数据:%o",data);
        //   var data = {
        //      list : [
        //       {
        //         _id : "2",
        //         name:"四月水果当季尝",
        //         images:["images/pic_003.jpg","images/pic_003.jpg"],
        //         module:"recipes",
        //         api:"recipes",
        //         id:"2e07d2aeas454df5feb8400",
        //         creator : "小明",
        //         create_time :"2016-05-17T01:03:27.453Z"
        //       }
        //     ],
        //   count : 100
        // }
      });
    },
    /*
    * @public {function} 绑定轮播图列表数据
    * @param {array} objArr 对象的数组
    */
    fillDataSwiperList:function( objArr ){
      var html = tplIndex.tplSwiperList(objArr);
      var $swiperWrapper = $('#js-section-swiper-container .swiper-wrapper');
      $swiperWrapper.empty().append(html);
    },
    /*
    * @public {function} 获取标签
    * @param {object} aData 申请应用数据
    */
    getDataLabels:function(aData){
      var self = this,
      url = common.apiHost+'/module/experts/'+aData.app_id+'/api/label/list',
      data = {
        limit : 200
      };
      var jsonData = JSON.stringify(data);
      util.appAjax({
        url:url,
        data:jsonData,
        headers:{'Access-Token':aData.access_token}
      }).done(function(data){
        console.info("获取标签响应的数据:%o",data);
        var data = {
           list : [
            {
              _id :"1",
               label : "高血压"
            },
            {
              _id :"2",
               label : "高血糖"
            },
            {
              _id :"3",
               label : "高血脂"
            },
            {
              _id :"4",
               label : "高尿酸"
            },
            {
              _id :"5",
               label : "低血氧"
            }
           ]
        }
        self.fillDataLabels(data);
      });
    },
    /*
    * @public {function} 绑定标签数据
    * @param {object} obj 数据对象
    */
    fillDataLabels :function( obj ){
      var $wrapUserLabels = $('#js-wrap-userlabels');
      var html = tplIndex.tplDialog(obj);
      $wrapUserLabels.empty().append(html);
    },
    /*
    * @public {function} 获取用户属性
    * @param {object} lData 登陆用户数据
    * @param {object} pData 用户属性数据
    */
    getDataUserProperty:function(lData,pData){
      var self = this;
      if(pData && pData.label){//有标签
        $('#js-wrap-userlabels').remove();
        //专家应用申请凭证
        common.ajaxApplyToken(common.dietitian_appid,lData)
        .then(function(aData){

          var condition = {
            query : {'label':{"$in":pData.label}},
            limit:1
          };
          //获取专家列表
          common.getDataList(aData,condition);
        })
        //菜谱应用申请凭证
        common.ajaxApplyToken(common.menu_appid,lData)
        .then(function(aData){
          var condition = {
            query : {'properties.symptom.name':{'$in':pData.label}}
          };
          //获取菜谱列表
          common.getDataList(aData,condition);
        })
         //运营位管理申请凭证
        // common.ajaxApplyToken(common.operate_appid,lData)
        // .then(function(aData){
        //   //获取运营位Id
        //   self.getDataOperatePositionId(aData)
        //   .then(function(oData){
        //     //获取轮播图列表
        //     self.getDataSwiperList(aData,pData,oData);
        //   })
        // })
      }else{//无标签
        $('#js-wrap-userlabels').show();
        //专家应用申请凭证
        common.ajaxApplyToken(common.dietitian_appid,lData)
        .then(function(aData){
          //查询设置的标签
          self.getDataLabels(aData);
        })
      }
    },
     /*
    * @public {function} 设置用户属性
    * @param {object} obj 用户属性
    */
    setDataUserProperty:function(obj){
      var self = this;
      $('#js-wrap-userlabels').remove();
      common.ajaxAppLoginToken().then(function(lData){
        console.info("设置用户属性提交的数据:%o",obj);
        var url = common.apiHost+'/v2/user/'+lData.user_id+'/property',
        jsonData = JSON.stringify(obj);
        util.appAjax({
          url:url,
          data:jsonData,
          headers:{'Access-Token':lData.access_token}
        }).done(function(data){
          console.info("设置用户属性响应的数据:%o",data);
        });
      });
    },
    /*
    * @public {function} 删除用户属性
    * @param {object} lData 用户登陆数据
    * @param {string} key 指定删除的属性key
    */
    deleteDataUserProperty:function(lData,key){
      var self = this;
      var url = common.apiHost+'/v2/user/'+lData.user_id+'/property/'+key;
      util.appAjax({
          url:url,
          type:'delete',
          headers:{'Access-Token':lData.access_token}
      }).done(function(data){
          console.info("删除用户属性响应的数据:%o",data);
      });
    },
    /*
    * @public {function} 获取运营位Id
    * @param {object} aData 申请应用数据
    */
    getDataOperatePositionId :function(aData){
      var defer = $.Deferred();
      var self = this;
      var url = common.apiHost+'/module/operatePosition/' + aData.app_id + '/api/operatePosition/list';
      util.appAjax({
          url:url,
          type:'post',
          headers:{'Access-Token':aData.access_token}
      }).done(function(data){
          console.info("获取运营位Id返回的数据:%o",data);
          var data = {
             list : [
              {
                _id : 2,
                name: "轮播图",
                width : 666,
                height : 666,
                content : [{"index":"1","id":"2e07d2ae5feb8400afi55"}],
                creator : "小明",
                create_time :"2016-05-17T01:03:27.453Z"
              }
            ],
            count : 100
          }
          defer.resolve(data);
      }).fail(function(xhr, errorType, error){
        console.error(error);
        defer.resolve(null);
      });
      return defer.promise();
    },
    /*
    * @public {function} 事件绑定
    */
    bindEvents:function(){
      var self = this;
      FastClick.attach(document.body);
      $(document).on('tap','#js-choice-confirm',function(){//确定提交标签
        if($(this).hasClass('disabled')) return;
        var obj = {'label':[]};
        $('#js-wrap-userlabels .label').each(function(){
          if($(this).hasClass('selected')){
            obj.label.push($(this).text());
          }
        })
        self.setDataUserProperty(obj);

      }).on('tap','#js-wrap-userlabels .label',function(){//标签选中交互
        if($(this).hasClass('selected')){
          $(this).removeClass('selected');
        }else{
          $(this).addClass('selected');
        }
        var selectedSize = $('#js-wrap-userlabels .selected').size();
        if( selectedSize === 0 ){
          $('#js-choice-confirm').addClass('disabled');
        }else{
          $('#js-choice-confirm').removeClass('disabled');
        }
      })
    }
  }
  module.exports = Index;
});