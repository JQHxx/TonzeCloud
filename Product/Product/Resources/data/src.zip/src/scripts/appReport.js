
requirejs(['zepto','app/report'],function($,Report) {
  $(function($){
    var report = new Report;
  })
});
