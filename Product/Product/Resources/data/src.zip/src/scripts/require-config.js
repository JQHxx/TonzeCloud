requirejs.config({
    baseUrl: 'scripts/lib',
    paths: {
        app: '../app',
        tpl:'../tpl',
        helper:'../helper',
        plugins:'../plugins',
        debug:'../debug'
    },
    shim: {
         'swiper.jquery': ['zepto'],
         'callbacks':['zepto'],
         'deferred':['zepto'],
         'touch':['zepto']
    },
    urlArgs: "v=" +  (new Date()).getTime()
});
