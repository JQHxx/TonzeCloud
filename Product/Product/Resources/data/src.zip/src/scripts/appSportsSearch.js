
requirejs(['zepto','app/search'],function($,Search) {
  $(function($){
    var search = new Search('sports');
  })
});
