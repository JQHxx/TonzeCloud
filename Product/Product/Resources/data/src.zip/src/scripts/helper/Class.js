define(function(require, exports, module) {
  var Class = {
    create: function() {
        return function() {
            this.initialize.apply(this , arguments);
        }
    }
  }
  module.exports = Class;
});