define(function(require, exports, module) {
     var browser = {
      versions:function(){
        var u = navigator.userAgent, app = navigator.appVersion;
        return{//移动终端浏览器版本信息
               trident: u.indexOf('Trident') > -1,//IE内核
               presto: u.indexOf('Presto') > -1,//opera内核
               webKit: u.indexOf('AppleWebKit') > -1,//苹果、谷歌内核
               gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1, //火狐内核
               mobile: !!u.match(/AppleWebKit.*Mobile.*/)||!!u.match(/AppleWebKit/),//是否为移动终端
               ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/),//ios终端
               android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, //android终端或者uc浏览器
               iPhone: u.indexOf('iPhone') > -1 || u.indexOf('Mac') > -1, //是否为iPhone或者QQHD浏览器
               iPad: u.indexOf('iPad') > -1,//是否iPad
               webApp: u.indexOf('Safari') == -1//是否web应该程序，没有头部与底部
        };
      }(),
      language:(navigator.browserLanguage || navigator.language).toLowerCase()
    }
  //Hybrid基本逻辑
  window.Hybrid = window.Hybrid || {};
  window.Hybrid.ui = window.Hybrid.ui || {};
  var customProtocolScheme = 'ios';
  var androidObjName = 'Xlink';
  Hybrid.callback = function (data) {
      var callbackId = data.callback;
      if(!callbackId) return;

      if(typeof data == 'string') data = JSON.parse(data);

      if(callbackId.indexOf('header_') != -1 && Hybrid['Header_Event']) {
          Hybrid['Header_Event'][callbackId] && Hybrid['Header_Event'][callbackId](data);
      } else {
          Hybrid[callbackId] && Hybrid[callbackId](data);
      }
      return true;
  };

  var bridgePostMsg = function (params) {
      var url = _getHybridUrl(params);

      console.log(url);

      //兼容ios6
      var ifr = $('<iframe style="display: none;" src="' + url + '"/>');
      $('body').append(ifr);
      setTimeout(function () {
          ifr.remove();
          ifr = null;
      }, 1000);

      return;

      if (browser.versions.ios) {
          //使用jsCore与native通信
          window.HybridRequestNative && HybridRequestNative(JSON.stringify(params));
      } else {
          //Android实现
          var ifr = $('<iframe style="display: none;" src="' + url + '"/>');
          $('body').append(ifr);
          setTimeout(function () {
              ifr.remove();
              ifr = null;
          }, 1000)
      }
  };

  var _getHybridUrl = function (params) {
      var paramStr = '', url = customProtocolScheme + '://', flag = '?';
      url += params.tagname; //时间戳，防止url不起效

      if (params.param) {
          paramStr = typeof params.param == 'object' ? encodeURIComponent(JSON.stringify(params.param)) : params.param;
          url += flag + paramStr;
      }

      if (params.callback) {
          //flag = '&';
          url += flag + params.callback;
          //delete params.callback;
      }
      return url;
  };

  _setEvent = function (t, tmpFn) {
      window[t] = function (data) {
          tmpFn(data);
          delete window[t];
      };
  };

  //处理组件通信的情况
  var _handleMessage = function(events, tagname) {
      var tmpFn, data = {};
      var t;

      for(var key in events) {
          t = 'hybrid_' + tagname +  '_' + key;
          data[key] = t;
          tmpFn = events[key];
          _setEvent(t, tmpFn);
      }

      return data;
  };

  var requestHybrid = function (params) {
      if(!params.tagname) {
          console.info('必须包含tagname');
      }
      //生成唯一执行函数，执行后销毁
      var tt = (new Date().getTime());
      var t =  params.tagname +  '_callback' + tt;
      var tmpFn;

      //处理有回调的情况
      if (params.callback) {
          tmpFn = params.callback;
          params.callback = t;

          window[t] = function (data) {
            tmpFn(data);
            delete window[t];
          }
      }

      bridgePostMsg(params);
  };

  var getHybridInfo = function () {
      var platform_version = {};
      var na = navigator.userAgent;
      na = na.toLowerCase();

      var info = na.match(/hybrid_\d\.\d\.\d/);

      if (info && info[0]) {
          info = info[0].split('_');
          if (info && info.length == 2) {
              platform_version.platform = info[0];
              platform_version.version = info[1];
          }
      }

      //*debug* 调试模拟环境
      if (_.getUrlParam().__platform) {
          platform_version.platform = _.getUrlParam().__platform;
          platform_version.version = _.getUrlParam().__version;
      }

      return platform_version;
  };

  var getVer = function () {
      var ver = getHybridInfo().version.replace(/\./g, '');
      if (ver) return parseInt(ver);
      return 0;
  };

  //版本在多少
  var versionAt = function (ver) {
      if (ver == getVer()) return true;
      return false;
  };

  var versionBefore = function (ver) {
      if (getVer() < ver) return true;
      return false;

  };

  var versionAfter = function (ver) {
      if (getVer() > ver) return true;
      return false;
  };

  var hybridCallback = function (opts) {
      //undefined, baidu_bus,
      var platform = _.getHybridInfo().platform || 'web';
      var mapping = {
          'web': '',
          'baidubox': 'bdbox_',
          'baidu_bus': 'bdbus_'
      };
      var callbackName = mapping[platform] || '';
      // 如果没有定义渠道callback 则默认为普通callback
      var callback = opts[callbackName + 'callback'] || opts['callback'];
      if (typeof callback == 'function') callback();
  };

  var registerHeaderCallback = function (ns, name, callback) {
      if (!window.Hybrid[ns]) window.Hybrid[ns] = {};
      window.Hybrid[ns][name] = callback;
  };

  var unRegisterHeaderCallback = function (ns) {
      if (!window.Hybrid[ns]) return;
      delete window.Hybrid[ns];
  };

  var _Hybrid = {};

  _Hybrid.registerHeaderCallback = registerHeaderCallback;
  _Hybrid.unRegisterHeaderCallback = unRegisterHeaderCallback;

  _Hybrid.getHybridInfo = getHybridInfo;
  _Hybrid.requestHybrid = requestHybrid;

  window.requestHybrid = requestHybrid;

  _Hybrid.hybridCallback = hybridCallback;
  _Hybrid.versionAt = versionAt;
  _Hybrid.versionBefore = versionBefore;
  _Hybrid.versionAfter = versionAfter;

  module.exports = _Hybrid;
});