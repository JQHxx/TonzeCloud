define(function(require, exports, module) {
  require('callbacks');
  require('deferred');
  require('touch');
  /*
  * @name {function} 工具方法
  */
  function util(){
    /*
    * @public {function} ajax
    * @param {object} options 配置
    * @return {object}  xhr对象实现了promise接口链式的回调
    */
     function appAjax( options ){
      var options = $.extend({
        type:'post',
        dataType:'json'
      }, options || {});
      return $.ajax(options);
    }
    /*
    * @public {function} isType
    * @param {string} type 数据类型
    * @return {function}
    */
    function isType(type) {
      return function(obj) {
        return Object.prototype.toString.call(obj) == "[object " + type + "]"
      }
    }
    /*
    * @public {function} queryString 获取url上的参数
    * @param {string} key  键
    * @return {string} 值
    */
    function queryString (key) {
        return (document.location.search.match(new RegExp("(?:^\\?|&)" + key + "=(.*?)(?=&|$)")) || ['', null])[1];
    }
    /*
    * @public {function} setParam 设置url上的参数值
    * @param {string} param  键
    * @param {string} value 值
    */
    function setParam(param,value){
      var query = location.search.substring(1);
      var p = new RegExp("(^|)" + param + "=([^&]*)(|$)");
      if(p.test(query)){
          var firstParam = query.split(param)[0];
          var secondParam = query.split(param)[1];
          if(secondParam.indexOf("&")>-1){
              var lastPraam = secondParam.split("&")[1];
              return  '?'+firstParam+'&'+param+'='+value+'&'+lastPraam;
          }else{
              if(firstParam){
                  return '?'+firstParam + param +'='+value;
              }else{
                  return '?'+param+'='+value;
              }
          }
      }else{
          if(query == ''){
              return '?'+param+'='+value;
          }else{
              return '?'+query+'&'+param+'='+value;
          }
      }
    }

    /*
    * @public {function} setItem 将value存储到key字段
    * @param {string} key  键
    * @param {string} value  值
    * @param {nubmer} expire 过期时间，小时
    */
    function setItem(key,value,expire){
      var expire = expire||0;
      expire = isType('string')(expire)?parseInt(expire):expire;
      var curTime = new Date().getTime() + expire * 3600 * 1000;
      localStorage.removeItem(key);
      localStorage.setItem(key,JSON.stringify({data:value,time:curTime}));
    }
    /*
    * @public {function} getItem 获取指定key本地存储的值
    * @param {string} key  键
    * @return {object}
    */
    function getItem(key){
        var data = localStorage.getItem(key);
        if( !data ) return null;
        var dataObj = JSON.parse(data);
        if (new Date().getTime() - dataObj.time > 0) {
            console.warn("缓存的key:"+key+" 已过期!");
            return null;
        }else{
          return dataObj.data;
        }
    }
    /*
    * @public {function} removeItem 清楚指定key本地存储的值
    * @param {string} key 键
    * @return {function}
    */
    function removeItem(key){
      return localStorage.removeItem(key);
    }
    /*
    * @public {function} clear 清楚本地存储的所有值
    * @return {function}
    */
    function clear(){
      return localStorage.clear();
    }
     /*
    * @public {function} isEmptyObject 判读空对象
    * @return {boolean} true: 空对象，false:非空
    */
    function isEmptyObject(e) {
      var t;
      for (t in e)
          return !1;
      return !0
    }
    /*
    * @public {function} unique 数组去重
    * @param {array} arr
    * @return {array}
    */
    function unique(arr) {
      var result = [], hash = {};
      for (var i = 0, elem; (elem = arr[i]) != null; i++) {
          if (!hash[elem]) {
              result.push(elem);
              hash[elem] = true;
          }
      }
      return result;
    }

    /*
    * @public {function} tips 自动关闭提示层
    */
    function tips( text){
        var $tips = $("<div class='mui-tips js-mui-tips'>"+ text +"</div>");
        $("body").find(".js-mui-tips").remove();
        $("body").append($tips);
        setTimeout(function(){
          $(".js-mui-tips").hide();
        },4000)
    }
    /*
    * @public {function} ClearBr 去除换行
    */
    function ClearBr(key) {
      key = key.replace(/<\/?.+?>/g,'');
      key = key.replace(/[\r\n]/g, '');
      key = key.replace(/[\n]/g, '');
      return key;
    }
    /*
    * @public {function} base64decode  base64解码
    */
    function base64decode(strIn) {
      strIn = ClearBr(strIn);
      if (!strIn.length || strIn.length % 4)
        return null;
      if (!strIn.length)
        return null;
      var str64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
      var index64 = [];
      for (var i = 0; i < str64.length; i++)
        index64[str64.charAt(i)] = i;
      var c0, c1, c2, c3, b0, b1, b2;
      var len = strIn.length;
      var len1 = len;
      if (strIn.charAt(len - 1) == '=')
        len1 -= 4;
      var result = [];
      for (var i = 0, j = 0; i < len1; i += 4) {
        c0 = index64[strIn.charAt(i)];
        c1 = index64[strIn.charAt(i + 1)];
        c2 = index64[strIn.charAt(i + 2)];
        c3 = index64[strIn.charAt(i + 3)];
        b0 = (c0 << 2) | (c1 >> 4);
        b1 = (c1 << 4) | (c2 >> 2);
        b2 = (c2 << 6) | c3;
        result.push(b0 & 0xff);
        result.push(b1 & 0xff);
        result.push(b2 & 0xff);
      }
      if (len1 != len) {
        c0 = index64[strIn.charAt(i)];
        c1 = index64[strIn.charAt(i + 1)];
        c2 = strIn.charAt(i + 2);
        b0 = (c0 << 2) | (c1 >> 4);
        result.push(b0 & 0xff);
        if (c2 != '=') {
          c2 = index64[c2];
          b1 = (c1 << 4) | (c2 >> 2);
          result.push(b1 & 0xff);
        }
      }
      /***********将数据转成16进制 start***********/
      var arr = result;
      var newArr = arr.map(function (item) {
        var centeritem = item.toString(16);
        return centeritem.length>1?centeritem:'0'+centeritem;
      });
      result = newArr;
      /************将数据转成16进制 end***************/
      return result;
    };
    /*
    * @public {function} base64encode  base64编码
    * @param {Object} data
    */
    function base64encode(data) {
      var str = String.fromCharCode.apply(null,data); // 先转换为二进制
      return btoa(str).replace(/.{76}(?=.)/g,'$&\n');
    }
    /*
    * @public {function} ms2hms  毫秒转化为时分秒
    * @param {number}  millis
    * @return {object}
    */
    function ms2hms( millis ){
      if( !millis ) return {hour:0,min:0,sec:0};
      var millis = parseInt(millis);
      var hours = Math.floor(millis / 36e5),
          mins = Math.floor((millis % 36e5) / 6e4),
          secs = Math.floor((millis % 6e4) / 1000);
      return {hour:hours,min:mins,sec:secs};
    }

    /*
    * @public {function} to16  转16进制
    * @param {array} numArr
    */
    function to16 (numArr) {
      var result = [];
      for (var i = 0; i < numArr.length; i++) {
        var num16 = parseInt(numArr[i],16)
        result.push(num16);
      }
      return result;
    }

    return {
      appAjax:appAjax,
      isType:isType,
      queryString:queryString,
      setParam:setParam,
      setItem:setItem,
      getItem:getItem,
      removeItem:removeItem,
      clear:clear,
      isEmptyObject:isEmptyObject,
      unique:unique,
      tips:tips,
      base64decode:base64decode,
      base64encode:base64encode,
      to16:to16,
      ms2hms:ms2hms
    }
  }
  module.exports = util();
});