
requirejs(['zepto','app/sports'],function($,Sprots) {
  $(function($){
    var sports = new Sprots;
  })
});
